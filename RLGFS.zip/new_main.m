% clc;
% clear all;

% set path
addpath('.\util');

% load dataset
addpath('.\usingdatasets');


[samplen,~]=size(fea{1});
[~,view_number]=size(fea);

for i=1:view_number
    X.data{i}=fea{i};
end

% for j=1:samplen
%     X.fea(j,:)=[fea{1}(j,:),fea{2}(j,:),fea{3}(j,:),fea{4}(j,:),fea{5}(j,:),fea{6}(j,:)];
% end

for j=1:samplen
    X.fea(j,:)=[fea{1}(j,:),fea{2}(j,:),fea{3}(j,:),fea{4}(j,:),fea{5}(j,:)];
end


[n,d]=size(X.fea);

FeaNumCandi = [100:100:500]; % feature dimension

[num, dimension] = size(X.fea); 

class_num=size(unique(gt),1);
label=gt;


%% LPP Paras
options = [];
options.NeighborMode = 'KNN';
options.k = 5;
options.WeightMode = 'HeatKernel';
options.t = 10;

%% run MVLRFS
alpha=[1e-4,1e-2,1,100,10000];
beta=[1e-4,1e-2,1,100,10000];
gamma=[1e-4,1e-2,1,100,10000];
lambda=[1e-4,1e-2,1,100,10000];

W = mvlatentfs(X, class_num, 1, 1, 1,1,options);

%% calculate weight
W1 = [];
for k = 1:dimension
    W1 = [W1 norm(W(k,:),2)];
end
%% test stage
[~,index] = sort(W1,'descend');
ACC=[];
NMI=[];
ACCstd=[];
NMIstd=[];
for j = 1:length(FeaNumCandi)
acc=[];
nmi=[];
for k = 1:20
    new_fea = X.fea(:,index(1:FeaNumCandi(j)));
    idx = kmeans(new_fea, class_num);
    res = bestMap(label,idx);
    RS_data{1}.AC(1,j)= length(find(label == res))/length(label); % calculate ACC 
    RS_data{1}.NMI(1,j) = MutualInfo(label,idx); % calculate NMI
%     disp(['MVLRFS ','Selected feature num: ',num2str(FeaNumCandi(j)),', Clustering MIhat: ',num2str(RS_data{1}.NMI(1,j)), ', AC: ',num2str(RS_data{1}.AC(1,j))]);
    acc=[acc;RS_data{1}.AC(1,j)];
    nmi=[nmi;RS_data{1}.NMI(1,j)];
end
ACC=[ACC;sum(acc)/20];
ACCstd=[ACCstd;std(acc)];
NMI=[NMI;sum(nmi)/20];
NMIstd=[NMIstd;std(nmi)];
end

