function [J]=UpdateJ(Z,mu,lambda,M)
svp=5;
temp=Z+M./mu;
[U,sigma,V] = svd(temp,'econ');
sigma = diag(sigma);
svp = length(find(sigma>lambda/mu));
if svp>=1
    sigma = sigma(1:svp)-lambda/mu;
else
    svp = 1;
    sigma = 0;
end
J = U(:,1:svp) * diag(sigma) * V(:,1:svp)';
