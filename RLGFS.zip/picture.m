% clc;
% clear all;

% set path
addpath('.\util');

% load dataset
addpath('.\usingdatasets');
addpath('.\convergence');

[samplen,~]=size(fea{1});
[~,view_number]=size(fea);

for i=1:view_number
    X.data{i}=fea{i};
end

% for j=1:samplen
%     X.fea(j,:)=[fea{1}(j,:),fea{2}(j,:),fea{3}(j,:),fea{4}(j,:),fea{5}(j,:),fea{6}(j,:)];
% end

for j=1:samplen
    X.fea(j,:)=[fea{1}(j,:),fea{2}(j,:),fea{3}(j,:),fea{4}(j,:),fea{5}(j,:)];
end


[n,d]=size(X.fea);

FeaNumCandi = [100:100:500]; % feature dimension

[num, dimension] = size(X.fea); 

class_num=size(unique(gt),1);
label=gt;


%% LPP Paras
options = [];
options.NeighborMode = 'KNN';
options.k = 5;
options.WeightMode = 'HeatKernel';
options.t = 10;

initalsumS = zeros(n, n);

%% initial similarity matrix for each view
for v = 1:view_number
    S_d.data{v} = constructW(X.data{v},options);
    initalsumS = initalsumS+S_d.data{v};
end 

[W,obj,weightvector,S] = mvlatentfs(X, class_num, 1, 1, 1, 1, initalsumS, S_d);

plot(obj);


selection=[5:5:50];
a=[1,selection];

plot(obj,'Linewidth',1.6,'Marker','o','MarkerIndices',a,'MarkerSize',6,'Color',[0.3010 0.7450 0.9330])
grid on
set(gca,'GridColor','k','GridAlpha',0.2,'FontWeight','bold');
xlabel('The number of iterations','FontWeight','bold')
ylabel('Objective function value','FontWeight','bold')


% selection=[5:5:50];
% a=[1,selection];
% hold on;
% h1=plot(weightvector(1,:),'Linewidth',1.6,'Marker','.','MarkerIndices',a,'MarkerSize',10,'Color',[0 0.4470 0.7410])
% h2=plot(weightvector(2,:),'Linewidth',1.6,'Marker','.','MarkerIndices',a,'MarkerSize',10,'Color',[0.8500 0.3250 0.0980])
% h3=plot(weightvector(3,:),'Linewidth',1.6,'Marker','.','MarkerIndices',a,'MarkerSize',10,'Color',[0.9290 0.6940 0.1250])
% h4=plot(weightvector(4,:),'Linewidth',1.6,'Marker','.','MarkerIndices',a,'MarkerSize',10,'Color',[0.4940 0.1840 0.5560])
% h5=plot(weightvector(5,:),'Linewidth',1.6,'Marker','.','MarkerIndices',a,'MarkerSize',10,'Color',[0.4660 0.6740 0.1880])
% h6=plot(weightvector(6,:),'Linewidth',1.6,'Marker','.','MarkerIndices',a,'MarkerSize',10,'Color',[0.3010 0.7450 0.9330])
% grid on
% set(gca,'GridColor','k','GridAlpha',0.2,'FontWeight','bold');
% xlabel('The number of iterations','FontWeight','bold')
% ylabel('Weights for all views','FontWeight','bold')
% 
% legend([h1,h2,h3,h4,h5,h6],'view 1','view 2','view 3','view 4','view 5','view 6','location','northwest');


% hold on;
% h1=plot(weightvector(1,:),'Linewidth',1.6,'Marker','.','MarkerIndices',a,'MarkerSize',10,'Color',[0 0.4470 0.7410])
% h2=plot(weightvector(2,:),'Linewidth',1.6,'Marker','.','MarkerIndices',a,'MarkerSize',10,'Color',[0.8500 0.3250 0.0980])
% h3=plot(weightvector(3,:),'Linewidth',1.6,'Marker','.','MarkerIndices',a,'MarkerSize',10,'Color',[0.9290 0.6940 0.1250])
% h4=plot(weightvector(4,:),'Linewidth',1.6,'Marker','.','MarkerIndices',a,'MarkerSize',10,'Color',[0.4940 0.1840 0.5560])
% h5=plot(weightvector(5,:),'Linewidth',1.6,'Marker','.','MarkerIndices',a,'MarkerSize',10,'Color',[0.4660 0.6740 0.1880])
% grid on
% set(gca,'GridColor','k','GridAlpha',0.2,'FontWeight','bold');
% xlabel('The number of iterations','FontWeight','bold')
% ylabel('Weights for all views','FontWeight','bold')
% 
% legend([h1,h2,h3,h4,h5],'view 1','view 2','view 3','view 4','view 5','location','northwest');


% hold on;
% h1=plot(weightvector(1,:),'Linewidth',1.6,'Marker','.','MarkerIndices',a,'MarkerSize',10,'Color',[0 0.4470 0.7410])
% h2=plot(weightvector(2,:),'Linewidth',1.6,'Marker','.','MarkerIndices',a,'MarkerSize',10,'Color',[0.8500 0.3250 0.0980])
% h3=plot(weightvector(3,:),'Linewidth',1.6,'Marker','.','MarkerIndices',a,'MarkerSize',10,'Color',[0.9290 0.6940 0.1250])
% grid on
% set(gca,'GridColor','k','GridAlpha',0.2,'FontWeight','bold');
% xlabel('The number of iterations','FontWeight','bold')
% ylabel('Weights for all views','FontWeight','bold')
% 
% legend([h1,h2,h3],'view 1','view 2','view 3','location','northwest');

