function [W,obj,weightvector,S] = mvlatentfs(X, n_class, alpha, beta, gama,lambda,initalsumS,S_d)
% X: multi-view data matrix n*d*v
% n_class: numbr of class 
% alpha, beta, gama, lambda: parameters
% options: LPP Paras

    weightvector=[];
    [n, d] = size(X.fea);
    view_num = length(X.data);
    weight_vector = ones(view_num,1)*(1/view_num);
    S = zeros(n, n);
%     initalsumS = zeros(n, n);
    eps = 1e-6;
    rho = 1.1;
    mu = 1e-6;
    max_mu = 1e6;
    Y = zeros(n,n);
    J = zeros(n,n);
%     lb = zeros(view_num,1);
%     ub = ones(size(lb));
%     Aeq = ones(1,view_num);
%     beq = 1;
    weight = [];
      
    weightsumS = initalsumS/view_num;
    S=0.5*(abs(weightsumS)+abs(weightsumS'));
    
    %% initial multi-view L   
    D_valuev = sum(S,2);
    sumS = spdiags(D_valuev,0,n,n);
    L = sumS-S;
  
   %% initial V
    V = 2 * full(sqrt(mean(mean(S)) / n_class)) * rand(n, n_class);
    D = eye(d,d);

    
    % iter assignment
    iter = 1;
    maxIter = 20;
    while iter <= maxIter
        
        % Update W
        ans=X.fea'*X.fea+alpha*D+gama*X.fea'*L*X.fea;
        M = inv(ans);
        W = M*X.fea'*V;
        Wi = sqrt(sum(W.*W,2)+eps);
        diagweight = 0.5./Wi;
        D = diag(diagweight);
        
        % Update V
        H = eye(n)-X.fea*M*X.fea';
        V = updateV(S,V,H,beta);
%         V=V.*(2*X.fea*W+4*beta*S*V)./(2*V+4*beta*V*V'*V);

        
        %Update S 
        S = (2*beta*V*V'-Y+mu*J+2*weightsumS)/(2*beta+2+mu);
        SS=0.5*(abs(S)+abs(S'));
        D_valuev = sum(SS,2);
        sumS = spdiags(D_valuev,0,n,n);
        L = sumS-SS;

        %Update auxiliary variable J��00
        J = UpdateJ(S,mu,lambda,Y);
        
        %Update weight_vector
        %ƴ��ÿ����ͼ��SΪ����
        temp_vector = zeros(n*n,1);
        Z = zeros(n*n,view_num);

        for i = 1:view_num
            temp_vector=S_d.data{i}(:);
            Z(:,i) = temp_vector;
        end 
%         Q = Z'*Z;
%         p = 2*Z'*S(:);
%         weight_vector = updateweight(weight_vector,Q,p);
%         Q = Z'*Z;
%         f = -(2*S(:)'*Z)';
%         
%         weight_vector = quadprog(Q,f,[],[],Aeq,beq,lb,ub);

        vectorS = S(:);

        weight_vector = jointupdatew(Z,vectorS,weight_vector);
        weight = [weight;weight_vector];
        
        for j = 1:n
            formulation_part = zeros(n,1);
            for i = 1:view_num
                formulation_part = formulation_part + weight_vector(i)*S_d.data{i}(:,j);
            end 
            weightsumS(:,j)=formulation_part;
        end
        
        %update multipuliers
        mu=min(rho*mu,max_mu);
        Y = Y + mu*(S-J);
        
        
        obj1=norm(X.fea*W-V,'fro')^2+alpha*sum(sqrt(sum(W.^2,1)))+gama*trace(W'*X.fea'*L*X.fea*W);
        sValue=svd(S);
        sum(sValue);
        objsum=lambda*sum(sValue)+obj1+beta*norm(S-V*V','fro')^2+norm(S-weightsumS,'fro')^2;
        
        
        obj(iter)=objsum;
        weightvector(:,iter)=weight_vector;
%         disp(['obj value: ',num2str(objValue)]);
        
        if iter >= 3
            if abs((obj(iter)-obj(iter-1))/obj(iter)) <= eps
                break;
            end
        end
        iter = iter + 1;
    end

end