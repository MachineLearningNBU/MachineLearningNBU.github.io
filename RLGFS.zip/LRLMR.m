function [W, V] = LRLMR(X, A,L, n_class, alpha, beta, gama)
% X: data matrix n*d
% A: similarity matrix
% L: Laplacian matrix
% n_class: numbr of class 
% alpha, beta, gama: parameters
    [nSamp, nFeat] = size(X);
    V = 2 * full(sqrt(mean(mean(A)) / n_class)) * rand(nSamp, n_class);
    D = eye(nFeat);
    iter = 1;
    maxIter = 100;
    while iter <= maxIter
        M = inv(X'*X+alpha*D+gama*X'*L*X);
        W = M*X'*V;
        Wi = sqrt(sum(W.*W,2)+eps);
        d = 0.5./Wi;
        D = diag(d);
        H = eye(nSamp)-X*M*X';
        V = updateV(A,V,H,beta);     
        obj(iter) = trace(V'*H*V)+beta/2*norm((A-V*V'),'fro')^2;
        fprintf('Iter %d\tobj=%f\n',iter,obj(end));
        iter = iter + 1;
    end
end