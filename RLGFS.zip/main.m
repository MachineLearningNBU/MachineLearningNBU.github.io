% clc;
% clear all;

% set path
addpath('.\util');

% load dataset
addpath('.\usingdatasets');


% mapminmax
for i=1:size(fea,2)
   fea{i}=mapminmax(fea{i}',0,1)';
end

warning('off');

FeaNumCandi = [100:100:500]; % feature dimension

class_num = size(unique(gt),1);  %classnumber

%X.fea deal
n=size(gt,1);
feasum=[];
% for i=1:n
%     feasum(i,:)=[fea{1}(i,:),fea{2}(i,:),fea{3}(i,:),fea{4}(i,:),fea{5}(i,:),fea{6}(i,:)];
% end
for i=1:n
    feasum(i,:)=[fea{1}(i,:),fea{2}(i,:),fea{3}(i,:)];
end
[num, dimension] = size(feasum);  
label=gt;

%% run MVLRFS
lambda=[1e-4,1e-2,1,100,10000];
beta=[1e-4,1e-2,1,100,10000];
gamma=[1e-4,1e-2,1,100,10000];


for i=1:size(lambda,2)
for j=1:size(beta,2)
for k=1:size(gamma,2)
% [W, V,itervalue] = MVLRFS(fea,feasum,class_num, lambda(i), beta(j), gamma(k),1);

[W, V,itervalue] = MVLRFS(fea,feasum,class_num, lambda(i), beta(j), gamma(k),1)
% objvalue=[objvalue;itervalue];
% plot(itervalue);


allAcc=[];
allnmi=[];
allACCstd=[];
allNMIstd=[];
objvalue=[];
%% calculate weight
W1 = [];
for k = 1:dimension
    W1 = [W1 norm(W(k,:),2)];
end
%% test stage
[~,index] = sort(W1,'descend');
ACC=[];
NMI=[];
ACCstd=[];
NMIstd=[];
for j = 1:length(FeaNumCandi)
acc=[];
nmi=[];
for k = 1:20
    new_fea = feasum(:,index(1:FeaNumCandi(j)));
    idx = kmeans(new_fea, class_num);
    res = bestMap(label,idx);
    RS_data{1}.AC(1,j)= length(find(label == res))/length(label); % calculate ACC 
    RS_data{1}.NMI(1,j) = MutualInfo(label,idx); % calculate NMI
%     disp(['MVLRFS ','Selected feature num: ',num2str(FeaNumCandi(j)),', Clustering MIhat: ',num2str(RS_data{1}.NMI(1,j)), ', AC: ',num2str(RS_data{1}.AC(1,j))]);
    acc=[acc;RS_data{1}.AC(1,j)];
    nmi=[nmi;RS_data{1}.NMI(1,j)];
end
ACC=[ACC;sum(acc)/20];
ACCstd=[ACCstd;std(acc)];
NMI=[NMI;sum(nmi)/20];
NMIstd=[NMIstd;std(nmi)];
end
allAcc=[allAcc;ACC];
allnmi=[allnmi;NMI];
allACCstd=[allACCstd;ACCstd];
allNMIstd=[allNMIstd;NMIstd];

% plot(itervalue);

end
end
end

number=size(allAcc,1);
final=zeros(number,4);
for j=1:number
    final(j,1:4)=[allAcc(j,1),allACCstd(j,1),allnmi(j,1),allNMIstd(j,1)];
end

[newvalue,endindex]=sort(allAcc,'descend');

final(endindex(1:10),:);
