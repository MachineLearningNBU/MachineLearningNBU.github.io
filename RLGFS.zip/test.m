class_num=size(unique(gt),1);
label=gt;
[samplen,~]=size(fea{1});

% for j=1:samplen
%     X.fea(j,:)=[fea{1}(j,:),fea{2}(j,:),fea{3}(j,:),fea{4}(j,:),fea{5}(j,:),fea{6}(j,:)];
% end

for j=1:samplen
    X.fea(j,:)=[fea{1}(j,:),fea{2}(j,:),fea{3}(j,:),fea{4}(j,:),fea{5}(j,:)];
end

X.fea = mapminmax(X.fea',0,1)';

ACC=[];
NMI=[];
ACCstd=[];
NMIstd=[];

acc=[];
nmi=[];
for k = 1:20
    idx = kmeans(X.fea, class_num);
    res = bestMap(label,idx);
    acc111 = length(find(label == res))/length(label); % calculate ACC 
    nmi111 = MutualInfo(label,idx); % calculate NMI
    acc=[acc;acc111];
    nmi=[nmi;nmi111];
end
ACC=[ACC;sum(acc)/20];
ACCstd=[ACCstd;std(acc)];
NMI=[NMI;sum(nmi)/20];
NMIstd=[NMIstd;std(nmi)];
