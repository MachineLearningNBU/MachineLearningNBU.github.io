function [W, V] = MVLRFS(X,n_class, alpha, beta, gama,p)
% X: data matrix n*d
% n_class: numbr of class 
% alpha, beta, gama: parameters 
    % initial distance parameters of weight_function
    
    [n, d] = size(X.fea);
    view_num=length(X.data);
    o = ones(view_num, n)*(1/view_num);
    S = zeros(n, n);
    eps = 0.0001;
    
    %% initial similarity matrix for each view
    for v = 1:view_num
         S_d.data{v} = constructW(X.data{v});
    end 
    S = (S_d.data{1}+S_d.data{2})/2;
    S = S./repmat(sqrt(sum(S.^2,1)),size(S,1),1);
    
    
    %% initial V   
    A = S;
    Degree = sum(A,2);   
    % normalized laplacian
    Degree=diag(sqrt(1./Degree));
    L=eye(size(A,1))-Degree*A*Degree;
%     [U_w,S_w] = eig(full(L));
%     Eigen=real(S_w^(0.5)*U_w'*X.fea);
    
    V = 2 * full(sqrt(mean(mean(A)) / n_class)) * rand(n, n_class);

    D1 = eye(d);
    D2 = eye(n);
    
    iter = 1;
    maxIter = 20;
    while iter <= maxIter
        % Update W
        M = inv(X.fea'*X.fea+alpha*D1+gama*Eigen'*D2*Eigen);
        W = M*X.fea'*V;
        Wi = sqrt(sum(W.*W,2)+eps);
%         Wip = power(Wi,2-p);
%         d1 = p./(2*Wip);
        D1 = diag(Wi);
        
        H = eye(n)-X.fea*M*X.fea';
        % Update V
        V = updateV(A,V,H,beta);     
        % Update A 
        for j = 1:n
            formulation_part = zeros(n,1);
            for i = 1:view_num
                formulation_part = formulation_part + o(i,j)*S_d.data{v}(:,j);
            end 
            S(:,j)=formulation_part;
        end  
        A = (2*S+2*beta*V*V'+X.fea*W*W'*X.fea')/(2*beta+2);
       
        Degree = sum(A,2);   
        % normalized laplacian
        Degree=diag(sqrt(1./Degree));
        L=eye(size(A,1))-Degree*A*Degree;
        [U_w,S_w] = eig(full(L));
        Eigen=real(S_w^(0.5)*U_w'*X.fea);
        Eigeni = sqrt(sum((Eigen*W).*(Eigen*W),2)+eps);
        Eigenip = power(Eigeni,2-p);
        d2 = p./(2*Eigenip);
        D2 = diag(d2);
        
        % Update wij
        for j = 1:n
            B_j = zeros(n,view_num);
            for v = 1:view_num
                B_j(:,v) = S(:,j)-S_d.data{v}(:,j);
            end
            o(:,j) = ((B_j'*B_j+eye(v)*1e-5)\ones(view_num,1))/(ones(view_num,1)'/(B_j'*B_j+eye(v)*1e-5)*ones(view_num,1));
        end
   
        
        obj(iter) = beta/2*norm((A-V*V'),'fro')^2+norm((A-S),'fro')^2+norm((X.fea*W-V),'fro')^2+alpha*trace(W'*D1*W)+gama*trace(W'*Eigen'*D2*Eigen*W);
        fprintf('Iter %d\tobj=%f\n',iter,obj(end));
        iter = iter + 1;
    end
end