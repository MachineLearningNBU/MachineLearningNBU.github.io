function V = updateV(A,V,H,beta)
    grad = 2*H*V-2*beta*(A-V*V')*V;
    stepsize = 1;
    Vn = max(V-stepsize*grad, 0);
    oldobj = trace(V'*H*V)+beta/2*norm((A-V*V'),'fro')^2;
    newobj = trace(Vn'*H*Vn)+beta/2*norm((A-Vn*Vn'),'fro')^2;
    if newobj - oldobj > 0.1*sum(sum(grad.*(Vn-V)))
        while true
            stepsize = stepsize*0.1;
            Vn = max(V - stepsize*grad, 0);
            newobj = trace(Vn'*H*Vn)+beta/2*norm((A-Vn*Vn'),'fro')^2;
            if newobj - oldobj <= 0.1*0.1*sum(sum(grad.*(Vn-V)))
                V = Vn;
                break;
            end
        end
    else
        V = Vn;
    end
end