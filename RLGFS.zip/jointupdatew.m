function [weight_vector] = jointupdatew(Z,vectorS,weight_vector)

    eps=0.001;
    rho = 1.1;
    mu = 1e-4;
    max_mu = 1e10;
    [a,b] = size(weight_vector);
    I = eye(a);
    substitute_vector = zeros(a,b);
    Y = zeros(a,b);
    
    iter = 1;
    
    while iter<=20
    
    weight_vector = EProjSimplex_new(substitute_vector-Y/mu);
        
    substitute_vector = inv(Z'*Z+mu*I)*(Z'*vectorS+Y+mu*weight_vector);
    
    Y = Y + mu*(weight_vector-substitute_vector);
    
    mu=min(rho*mu,max_mu);
    
    iter = iter + 1;
    
    end
    
end