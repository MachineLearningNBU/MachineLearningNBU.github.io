function [weight_vector] = updateweight(weight_vector,M,p)

    eps=0.001;
    rho = 1.01;
    mu = 1e-4;
    max_mu = 1e10;
    [a,b] = size(weight_vector);
    Y = zeros(a,b);
    
    while 1
    
    old_obj = weight_vector;
    
    substitute_vector = weight_vector + 1/mu*(Y-M'*weight_vector);
    
    beta = 1/mu*(mu*substitute_vector-Y-M*substitute_vector+p);
    
    weight_vector = EProjSimplex_new(beta);
    new_obj = weight_vector;
    
    Y = Y + mu*(weight_vector-substitute_vector);
    
    mu=min(rho*mu,max_mu);
    
    if max(abs(new_obj-old_obj)) <= eps
        break
    end
    
    end
    
end