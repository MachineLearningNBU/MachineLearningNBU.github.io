% clc;
% clear all;

% set path
addpath('.\util');

% load dataset
addpath('.\usingdatasets');

load('MSRC_v1');

[samplen,~]=size(fea{1});
[~,view_number]=size(fea);

for i=1:view_number
    X.data{i}=fea{i};
end

% for j=1:samplen
%     X.fea(j,:)=[fea{1}(j,:),fea{2}(j,:),fea{3}(j,:),fea{4}(j,:),fea{5}(j,:),fea{6}(j,:)];
% end

for j=1:samplen
    X.fea(j,:)=[fea{1}(j,:),fea{2}(j,:),fea{3}(j,:),fea{4}(j,:),fea{5}(j,:)];
end

% Data standardization
for i=1:view_number
 X.data{i}=mapminmax(X.data{i}',0,1)';
end
X.fea=mapminmax(X.fea',0,1)';

[n,d]=size(X.fea);

% Add 5% Gaussian noise
noise_level = 0.2;
X_noisy = X;
for i = 1:view_number
   std_view = std(X_noisy.data{i}(:));
   noise = noise_level * std_view * randn(size(X_noisy.data{i}));
   X_noisy.data{i} = X_noisy.data{i} + noise;
   X_noisy.data{i} = max(X_noisy.data{i}, 0);
end

std_fea = std(X_noisy.fea(:));
noise_fea = noise_level * std_fea * randn(size(X_noisy.fea));
X_noisy.fea = X_noisy.fea + noise_fea;
X_noisy.fea = max(X_noisy.fea, 0);

FeaNumCandi = [100:100:500]; % feature dimension

[num, dimension] = size(X.fea); 

class_num=size(unique(gt),1);
label=gt;


%% LPP Paras
options = [];
options.NeighborMode = 'KNN';
options.k = 5;
options.WeightMode = 'HeatKernel';
options.t = 10;

initalsumS = zeros(n, n);

%% initial similarity matrix for each view
for v = 1:view_number
    S_d.data{v} = constructW(X.data{v},options);
    initalsumS = initalsumS+S_d.data{v};
end 

%% run MVLRFS
alpha=[1e-4,1e-2,1,100,10000];
beta=[1e-4,1e-2,1,100,10000];
gamma=[1e-4,1e-2,1,100,10000];
lambda=[1e-4,1e-2,1,100,10000];

allAcc=[];
allnmi=[];
allACCstd=[];
allNMIstd=[];
rankmvlatent=[];

iter=0;

for i=1:size(alpha,2)
for o=1:size(beta,2)
for s=1:size(gamma,2)
for h=1:size(lambda,2)

% W = mvlatentfs(X, class_num, 1e-4, 1e-4, 1e-4, 1,options);

W = mvlatentfs(X, class_num, alpha(i), beta(o), gamma(s), lambda(h), initalsumS, S_d);

iter=iter+1

%% calculate weight
W1 = [];
for m = 1:dimension
    W1 = [W1 norm(W(m,:),2)];
end
%% test stage
[~,index] = sort(W1,'descend');
rankmvlatent(:,iter)=index;
ACC=[];
NMI=[];
ACCstd=[];
NMIstd=[];
for j = 1:length(FeaNumCandi)
acc=[];
nmi=[];
for k = 1:20
    new_fea = X.fea(:,index(1:FeaNumCandi(j)));
    idx = kmeans(new_fea, class_num);
    res = bestMap(label,idx);
    acc111 = length(find(label == res))/length(label); % calculate ACC 
    nmi111 = MutualInfo(label,idx); % calculate NMI
    acc=[acc;acc111];
    nmi=[nmi;nmi111];
end
ACC=[ACC;sum(acc)/20];
ACCstd=[ACCstd;std(acc)];
NMI=[NMI;sum(nmi)/20];
NMIstd=[NMIstd;std(nmi)];
end
allAcc=[allAcc;ACC];
allnmi=[allnmi;NMI];
allACCstd=[allACCstd;ACCstd];
allNMIstd=[allNMIstd;NMIstd];
end
end
end
end

number=size(allAcc,1);
final=zeros(number,4);
for j=1:number
    final(j,1:4)=[allAcc(j,1),allACCstd(j,1),allnmi(j,1),allNMIstd(j,1)];
end

[newvalue,endindex]=sort(allAcc,'descend');

final(endindex(1:10),:);


