function [Hv, obj] = TDUFS(fea, alpha, beta, lambda, eta, theta, v, n, c)
%% Construct
[v1, v2] = size(fea);
Hv = cell(v1, v2);
Cv = cell(v1, v2);
Dv = cell(v1, v2);
Zv = cell(v1, v2);
Ct = cell(v1, v2);
Pv = cell(v1, v2);
Gv = cell(v1, v2);
Diag1=cell(v1, v2); %%for H
U = zeros(n);

%% initial
V = rand(n, c);
miu = ones(v,1) / v;
rho = 1; gamma =2; max_rho = 1e12;
R = lambda*ones(v) - diag(lambda*ones(1,v)) + diag(eta*ones(1,v));
for num = 1:v
    fea{num} = fea{num}';
    d(num) = size(fea{num},1);
    Hv{num} = randn(d(num),c);
    Dv{num} = eye(d(num));
    Diag1{num} = eye(d(num));
    Zv{num} = constructW_PKN(fea{num});
%     Zv{num}(Zv{num}<0) = 0;
    Pv{num} = zeros(n);
    Gv{num} = zeros(n);
end

C0 = cell(v1, v2);
for num = 1:v
    [C0{num}, ~] = InitializeSIGs(fea{num}, 5, 0); % knn graph
    % S0{i} = eye(numSmp);
end
Cv = C0;

U = zeros(n);
for num = 1:v
    U = U + C0{num};
end
U = U/v;
for j = 1:n
    U(j,:) = U(j,:)/sum(U(j,:));
end

MaxIter=20;
obj=zeros(1,MaxIter);

%% Iter
for iter = 1:MaxIter
    %% optimization tensor
    C_tensor = cat(3, Cv{:,:});
    P_tensor = cat(3, Pv{:,:});
    Ct = C_tensor(:);
    Pt = P_tensor(:);
    sT = [n, n, v];
    [G, objV] = wshrinkObj(Ct + 1/rho * Pt, (n*alpha)/ rho, sT, 0, 3);
    G_tensor = reshape(G, sT);
    for num = 1 : v
        Gv{num} = G_tensor(:, :, num);
    end

    Pt = Pt + rho * (Ct - G);
    P_tensor = reshape(Pt, sT);
    for num = 1 : v
        Pv{num} = P_tensor(:, :, num);
    end

    %% optimization Cv
    zc = zeros(n);
    sumzc = zeros(n);
    for num = 1:v
        zc = R(num, num)*miu(num)*miu(num)*(Zv{num}-Cv{num});
        sumzc = sumzc + zc;
    end
    for num = 1:v
        A{num} = 2*fea{num}'*Hv{num}*Hv{num}'*fea{num} + 2*miu(num)*eye(n) + rho*eye(n);
        B{num} = 2*fea{num}'*Hv{num}*Hv{num}'*fea{num} + sumzc + 2*miu(num)*U + rho*Gv{num} - Pv{num};
        Cv{num} = max(A{num}\B{num}, 0);
        
        Cv{num} = max(Cv{num}, Cv{num}');
        Cv{num} = min(Cv{num}, Zv{num});
    end

    %% optimization Hv
    for num = 1:v
        LG = (eye(n) - Cv{num});
        LG = LG * LG';
        LG = (LG + LG') / 2;
        [Y, ~, ~]=eig1(LG, c, 0);
        %solve ||Y-XtH||F+alpha||H||21
        Hv{num}=(fea{num}*fea{num}'+beta*Dv{num})\(fea{num}*Y);
        Hi=sqrt(sum(Hv{num}.*Hv{num},2)+eps);
        diagonal=0.5./Hi;
        Dv{num}=diag(diagonal);
    end

    %% optimization U
    dist = V*V';
    U = zeros(n);
    for i=1:n
        c0 = zeros(1,n);
        for num = 1:v
            temp = Cv{num};
            c0 = c0 + miu(num)*temp(i,:);
        end
        idxa0 = find(c0>0);
        ci = c0(idxa0);
        ui = dist(i,idxa0);
        cu = (ci + theta*ui)/(sum(miu)+theta);
        U(i,idxa0) = EProjSimplex_new(cu);
    end

    %% optimization miu(v)
    for num = 1:v
        distUC = norm(U - Cv{num},'fro')^2;
        if distUC == 0
            distUC = eps;
        end
        miu(num) = 0.5/sqrt(distUC);
    end

    %% optimization V
    [V,~,~]=eig1(eye(n)-2*U, c, 0);

    %% error
    sumobj1 = 0;
    for i = 1:v
        for j = 1:v
            sumobj1 = sumobj1 + R(i, j)*miu(i)*miu(j)*trace((Zv{i}-Cv{i})*(Zv{j}-Cv{j})');
        end
    end
    sumobj2 = 0;
    for num = 1:v
        sumobj2=sumobj2 ...
              +norm(Hv{num}'*fea{num}-Hv{num}'*fea{num}*Cv{num}, 'fro')^2 ...
              +beta*trace(Hv{num}'*Dv{num}*Hv{num})...
              +miu(num)*norm(U-Cv{num}, 'fro')^2;
    end
    allobj = 0;
    allobj = sumobj1 + sumobj2 + alpha*objV + theta*norm(U-V*V', 'fro')^2;
    obj(iter)=real(allobj);
    
    rho = min(rho * gamma, max_rho);
end

end



