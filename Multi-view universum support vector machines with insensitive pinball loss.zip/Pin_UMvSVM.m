function [p,pre,F]=Pin_UMvSVM(U,xtr,xte,O,r1,r2,r3,tau)
% U: universum data
% xtr: Training data
% xte: Test data
% O: View weights
%r1: Loss penalty parameter
%r2: Consensus term penalty parameter
%r3: universum data penalty parameter
%tau:pinabll loss parameter
M=size(xtr,2);
epsilon_1=0.001;
epsilon_2=0.001;
epsilon_3=0.001;
type=1;
sigma=1;
for i=1:M
    K{i}.train=makekernel(xtr{i}.data,xtr{i}.data,type,sigma);
    K{i}.uu=makekernel(U{i}.data,U{i}.data,type,sigma);
    K{i}.xu=makekernel(xtr{i}.data,U{i}.data,type,sigma);
    K{i}.ux=makekernel(U{i}.data,xtr{i}.data,type,sigma);
    K{i}.L=xtr{i}.L;
    K{i}.test=makekernel(xte{i}.data,xtr{i}.data,type,sigma);
end
Y1=diag(xtr{1}.L); 
num_data=size(xtr{i}.data,1);
num_universum=size(U{i}.data,1);
e_data=ones(num_data,1);
E_data=ones(num_data,num_data);
e_universum=ones(num_universum,1);
E_universum=ones(num_universum,num_universum);

S_X1=[Y1 zeros(num_data,num_data) zeros(num_data,num_data) -Y1 zeros(num_data,num_data) zeros(num_data,num_data) -E_data E_data -E_data E_data zeros(num_data,num_data) zeros(num_data,num_data)];
S_X2=[zeros(num_data,num_data) Y1 zeros(num_data,num_data) zeros(num_data,num_data) -Y1 zeros(num_data,num_data) E_data -E_data zeros(num_data,num_data) zeros(num_data,num_data) -E_data E_data];
S_X3=[zeros(num_data,num_data) zeros(num_data,num_data) Y1 zeros(num_data,num_data) zeros(num_data,num_data) -Y1 zeros(num_data,num_data) zeros(num_data,num_data) E_data -E_data E_data -E_data];

S_U1=[-E_universum zeros(num_universum,num_universum) zeros(num_universum,num_universum) E_universum zeros(num_universum,num_universum) zeros(num_universum,num_universum)];
S_U2=[zeros(num_universum,num_universum) -E_universum zeros(num_universum,num_universum) zeros(num_universum,num_universum) E_universum zeros(num_universum,num_universum)];
S_U3=[zeros(num_universum,num_universum) zeros(num_universum,num_universum) -E_universum zeros(num_universum,num_universum) zeros(num_universum,num_universum) E_universum];
SS{1}.S=S_X1;
SS{2}.S=S_X2;
SS{3}.S=S_X3;
SS{1}.U=S_U1;
SS{2}.U=S_U2;
SS{3}.U=S_U3;

H_1=S_X1'*K{1}.train*S_X1/O(1,:)+S_X2'*K{2}.train*S_X2/O(2,:)+S_X3'*K{3}.train*S_X3/O(3,:);
H_2=S_U1'*K{1}.uu*S_U1/O(1,:)+S_U2'*K{2}.uu*S_U2/O(2,:)+S_U3'*K{3}.uu*S_U3/O(3,:);
H_3=S_X1'*K{1}.xu*S_U1/O(1,:)+S_X2'*K{2}.xu*S_U2/O(2,:)+S_X3'*K{3}.xu*S_U3/O(3,:);
H_4=S_U1'*K{1}.ux*S_X1/O(1,:)+S_U2'*K{2}.ux*S_X2/O(2,:)+S_U3'*K{3}.ux*S_X3/O(3,:);
H=[H_1,H_3;H_4,H_2];
H=(H+H')/2;

p=[(-1+epsilon_2)*ones(3*num_data,1);(1+epsilon_2./tau)*ones(3*num_data,1);epsilon_1*ones(6*num_data,1);epsilon_3*ones(3*num_universum,1);epsilon_3*ones(3*num_universum,1)];
b=[r1*ones(3*num_data,1);tau*r1*ones(3*num_data,1);r2*ones(3*num_data,1);r3*ones(3*num_universum,1);r3*ones(3*num_universum,1)];
EE=[E_data E_data];

w1=[e_data'*S_X1;e_data'*S_X2;e_data'*S_X3];
w2=[e_universum'*S_U1;e_universum'*S_U2;e_universum'*S_U3];
W1=[w1,w2] ;

A=blkdiag(blkdiag(E_data,E_data,E_data),blkdiag(E_data,E_data,E_data),blkdiag(EE,EE,EE),blkdiag(E_universum,E_universum,E_universum),blkdiag(E_universum,E_universum,E_universum));

[x,fval,exitflag] = quadprog(H,p,A,b,W1,zeros(M,1),zeros(9*num_data+9*num_universum,1),[]);
epsilon=10e-8;

for i=1:M
sv{i}.sv1=find(r1>x((i-1)*num_data+1:i*num_data,:)>epsilon);
ttttt=size(x,1);
b1=1./xtr{i}.L(sv{i}.sv1,:)'-x'*[SS{i}.S'*makekernel(xtr{i}.data,xtr{i}.data(sv{i}.sv1,:),type,sigma);SS{i}.U'*makekernel(U{i}.data,xtr{i}.data(sv{i}.sv1,:),type,sigma)]/O(i,:);
bb{i}.b=mean(b1);
end
w1=1/O(1,:)^2*x'*[S_X1'*K{1}.train*S_X1,S_X1'*K{1}.xu*S_U1;S_U1'*K{1}.ux*S_X1,S_U1'*K{1}.uu*S_U1]*x;
w2=1/O(1,:)^2*x'*[S_X2'*K{2}.train*S_X2,S_X2'*K{2}.xu*S_U2;S_U2'*K{2}.ux*S_X2,S_U2'*K{2}.uu*S_U2]*x;
w3=1/O(1,:)^2*x'*[S_X3'*K{3}.train*S_X3,S_X3'*K{3}.xu*S_U3;S_U3'*K{3}.ux*S_X3,S_U3'*K{3}.uu*S_U3]*x;

num_test=size(K{i}.test,1);
Yt=zeros(num_test,1);

 for cvtest=1:num_test
%             d=x'*T1'*makekernel(XU{1}.data,xte{1}.data,type,sigma)+x'*T2'*makekernel(XU{2}.data,xte{2}.data,type,sigma)+x'*T3'*makekernel(XU{3}.data,xte{3}.data,type,sigma)+O(1,:)*bb{1}.b+O(2,:)*bb{2}.b+O(3,:)*bb{3}.b;
d=x'*[S_X1'*makekernel(xtr{1}.data,xte{1}.data,type,sigma);S_U1'*makekernel(U{1}.data,xte{1}.data,type,sigma)]+x'*[S_X2'*makekernel(xtr{2}.data,xte{2}.data,type,sigma);S_U2'*makekernel(U{2}.data,xte{2}.data,type,sigma)]+x'*[S_X3'*makekernel(xtr{3}.data,xte{3}.data,type,sigma);S_U3'*makekernel(U{3}.data,xte{3}.data,type,sigma)]+O(1,:)*bb{1}.b+O(2,:)*bb{2}.b+O(3,:)*bb{3}.b;
if(d(:,cvtest)>=0)
                        Yt(cvtest,:)=1;
                   else
                        Yt(cvtest,:)=-1;
                   end
 end
pre=sum(abs(Yt-xte{1}.L)<0.5)/length(Yt)
[~,F]=accuracy(Yt,xte{1}.L);
p=[w1;w2;w3];
p=p/2;


