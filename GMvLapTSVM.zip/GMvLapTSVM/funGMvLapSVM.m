function [p,acc,c1,c2,c3]=funGMvLapSVM(XV,Utr,O)
    
    confuse=[];
    ac=[];
    NN=size(60,1);
    V=10;
    idx=crossvalind('Kfold',ones(50,1),V);
    M=size(XV,2);
    a=3;
    base=2;
    ac_v1=zeros(2*a+1,2*a+1,2*a+1,V);
for m=1:V
    test=(idx==m);
    train=~test;
    for j=1:M
        Xtr{j}.data=[XV{j}.A(train,:);XV{j}.B(train,:)];
        Xtr{j}.L=[ones(size(XV{j}.A(train,:),1),1);-ones(size(XV{j}.B(train,:),1),1)];
        Xte{j}.data=[XV{j}.A(test,:);XV{j}.B(test,:)];
        Xte{j}.L=[ones(size(XV{j}.A(test,:),1),1);-ones(size(XV{j}.B(test,:),1),1)];
    end
    for i=-a:a
       c1=base^i;
        for j=-a:a
          c2=base^j;
            for z=-a:a
          c3=base^z;
          [~,ac_v1(a+1+i,a+1+j,a+1+z,m),ac]=GMvLapSVM(Xtr,Utr,Xte,O,c1,c2,c3)
        end
        end 
    end
end

    ac_v1=sum(ac_v1,4);
    [yy0,yyi0]=sort(ac_v1(:));
    yyi0=min(find(ac_v1(:)>yy0(end)-1e-6));
    [indi,indj,indz]=ind2sub(size(ac_v1),yyi0);
    c1=base^(indi-a-1);
    c2=base^(indj-a-1);
    c3=base^(indz-a-1);
   %[ac(i)]=GEPSVM_a_mk(xte1,xte2,yte,A1,B1,A2,B2,N,M,mu,delta,gamma);
   [p,acc,ac]=GMvLapSVM(XV,Utr,XV,O,c1,c2,c3)
  %[ac(i)]=EPSVM_a_mlss(xte1,xte2,yte,A1,B1,A2,B2,N,M,mu,delta,nu);
   
end