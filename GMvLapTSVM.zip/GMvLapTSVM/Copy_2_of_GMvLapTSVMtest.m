clear
view{1,1} = 'fou'; % 200 * 76
view{2,1} = 'kar'; % 200 * 64
view{3,1} = 'fac'; % 200 * 216
view{4,1} = 'pix'; % 200 * 240
view{5,1} = 'zer'; % 200 * 47
view{6,1} = 'mor'; % 200 * 6  
%X_v1 = load(['./multifeat/mfeat-',view{v1,1},'.txt']); 
%X_v2 = load(['./multifeat/mfeat-',view{v2,1},'.txt']);
X_v{1}= load(['./multifeat/',view{1,1},'.scaled.txt']);
X_v{2}= load(['./multifeat/',view{2,1},'.scaled.txt']);
X_v{3}= load(['./multifeat/',view{3,1},'.scaled.txt']);
X_v{4}= load(['./multifeat/',view{4,1},'.scaled.txt']);
X_v{5}= load(['./multifeat/',view{5,1},'.scaled.txt']);
X_v{6}= load(['./multifeat/',view{6,1},'.scaled.txt']);

for i=1:1:6
    X{i}.A=X_v{i}(801:1000,:);
    X{i}.B=X_v{i}(1201:1400,:);  
end




M=3;
h1=20;
h=80;
NN=200;
add=102333;
nn=5;
for iter=5
    iter;
    t1=clock;
    seed =2^iter+add; randn('seed',seed), rand('seed',seed);
    S=randperm(NN);
    train=S(1:h1);
    test=S(h+1:end);
    utrain=S(h1+1:h);
    for i=1:M
        Xtr{i}.A=X{i}.A(train,:);
        Xtr{i}.B=X{i}.B(train,:);
        Utr{i}.data=[X{i}.A(utrain,:);X{i}.B(utrain,:)];
        Utr{i}.L=[ones(size(X{i}.A(utrain,:),1),1);-ones(size(X{i}.B(utrain,:),1),1)];
        XV{i}.A=X{i}.A(train,:);
        XV{i}.B=X{i}.B(train,:);
        XV{i}.data=[X{i}.A(train,:);X{i}.B(train,:)];
        Xtr{i}.data=[X{i}.A(train,:);X{i}.B(train,:)];
        Xtr{i}.L=[ones(size(X{i}.A(train,:),1),1);-ones(size(X{i}.B(train,:),1),1)];
        Xte{i}.data=[X{i}.A(test,:);X{i}.B(test,:)];
        Xte{i}.L=[ones(size(X{i}.A(test,:),1),1);-ones(size(X{i}.B(test,:),1),1)];
        XV{i}.L=[ones(size(X{i}.A(train,:),1),1);-ones(size(X{i}.B(train,:),1),1)];
    end
    O=zeros(M,1)/M;
    Oq=ones(M,1)/M;
    Op=ones(M,1)/M;
    z=0;r=10;
    while(norm(O-Op)>0.0001)
        z=1+z;
        O=Oq;
        Op=Oq;
        [p,q,acc,c1,c2,c3]=funGMvLapTSVM(XV,Utr,O);
        if(abs(rem(z,2)-1)<0.000001)
               for i=1
             if((r*(Oq(i,:)+Oq(i+1,:))+(q(i+1,:)-q(i,:))+p(i+1,:)-p(i,:))<0)
              Op(i,:)=0.00000001;
             else
              Op(i,:)=(r*(Oq(i,:)+Oq(i+1,:))+(q(i+1,:)-q(i,:))+p(i+1,:)-p(i,:))/2/r;
             end
             Op(i+1,:)=Oq(i,:)+Oq(i+1,:)-Op(i,:);
             Oq(i,:)=Op(i,:);
             Oq(i+1,:)=Op(i+1,:);
               end
        else
              for i=2
             if((r*(Oq(i,:)+Oq(i+1,:))+(q(i+1,:)-q(i,:))+p(i+1,:)-p(i,:))<0)
              Op(i,:)=0.00000001;
             else
              Op(i,:)=(r*(Oq(i,:)+Oq(i+1,:))+(q(i+1,:)-q(i,:))+p(i+1,:)-p(i,:))/2/r;
             end
             Op(i+1,:)=Oq(i,:)+Oq(i+1,:)-Op(i,:);
             Oq(i,:)=Op(i,:);
             Oq(i+1,:)=Op(i+1,:);
              end
        end
        t(z,:)=norm(O-Op);
         [~,~,a(z,:),~]=GMvLapTSVM(Xtr,Utr,Xte,Op,c1,c2,c3);
    end
   [p,q,accura(iter,:),acc(iter,:)]=GMvLapTSVM(Xtr,Utr,Xte,Op,c1,c2,c3);
end



 