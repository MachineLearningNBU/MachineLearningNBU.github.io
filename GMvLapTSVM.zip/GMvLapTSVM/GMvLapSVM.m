%funLapSVM_Rg.m
%Shiliang Sun, 2010-6-27, 2011-1-16, 2012-3-30

function [p,pre,ac]=GMvLapSVM(xtr,utr,xte,O,c1,c2,c3)
M=size(xtr,2);
type=1;
sigma=1;
for i=1:M
    K{i}.train=makekernel([xtr{i}.data;utr{i}.data],[xtr{i}.data;utr{i}.data],type,sigma);
    K{i}.K=makekernel(xtr{i}.data,[xtr{i}.data;utr{i}.data],type,sigma);
    K{i}.U=makekernel(utr{i}.data,[xtr{i}.data;utr{i}.data],type,sigma);
    K{i}.L=xtr{i}.L;
    K{i}.Y=diag(xtr{i}.L);
    K{i}.test=makekernel(xte{i}.data,[xtr{i}.data;utr{i}.data],type,sigma);
end
e=ones(size(K{1}.K,1),1);
for i=1:M
bandwidth{i}.b=mean(std([xtr{i}.data; utr{i}.data],0,1));  
L{i}.L=laplacianSun2([xtr{i}.data; utr{i}.data],6,bandwidth{i}.b);
J{i}.D=O(i,:)*K{i}.train+c1*O(i,:)*K{i}.train*L{i}.L*K{i}.train+2*c2*K{i}.train'*K{i}.train+c3*K{i}.K'*K{i}.Y'*K{i}.Y*K{i}.K;  
J{i}.D=(J{i}.D+J{i}.D')/2;
end
E=[J{1}.D -c2*K{1}.train'*K{2}.train -c2*K{1}.train'*K{3}.train;-c2*K{2}.train'*K{1}.train J{2}.D -c2*K{2}.train'*K{3}.train;-c2*K{3}.train'*K{1}.train -c2*K{3}.train'*K{2}.train J{3}.D];
F=[K{1}.K'*K{1}.Y; K{2}.K'*K{2}.Y; K{3}.K'*K{3}.Y];
E=(E+E')/2;
if rank(E)<size(E,1)-0.5
    temp625=max(eig(E));
    E=E+temp625*(1e-5)*eye(size(E)); %for numerical stability, full rank
end
CholFa=chol(E); 
InvE=CholFa\(CholFa'\eye(size(E)));
a=c3*InvE*F*e;

T=[O(1,:)*K{1}.test O(2,:)*K{2}.test O(3,:)*K{3}.test];
n=size(K{1}.train,1);    
w1=a(1:n,1)'*K{1}.train*a(1:n,1)+c1*a(1:n,1)'*K{1}.train*L{1}.L*K{1}.train*a(1:n,1);
w2=a(1+n:2*n,1)'*K{2}.train*a(1+n:2*n,1)+c1*a(1+n:2*n,1)'*K{2}.train*L{2}.L*K{2}.train*a(1+n:2*n,1);
w3=a(2*n+1:3*n,1)'*K{3}.train*a(2*n+1:3*n,1)+c1*a(2*n+1:3*n,1)'*K{3}.train*L{3}.L*K{3}.train*a(2*n+1:3*n,1);
nn=size(K{1}.test,1);
Yt=zeros(nn,1);
 for cvtest=1:nn
            d=T*a;
            %d=1/O(1,:)*(a1.*K{1}.L-bp12-bp13++bn12+bn13)'*K{1}.test'+1/O(2,:)*(a2.*K{2}.L-bp23+bn23)'*K{2}.test'+1/O(3,:)*(a3.*K{3}.L)'*K{3}.test';            
                   if(d(cvtest,:)>=0)
                        Yt(cvtest,:)=1;
                   else
                        Yt(cvtest,:)=-1;
                   end
 end
tt=size(utr{i}.data,1);
G=[O(1,:)*K{1}.U O(2,:)*K{2}.U  O(3,:)*K{3}.U];
 Yu=zeros(tt,1);
 for cvtest=1:tt
            d=G*a;
            %d=1/O(1,:)*(a1.*K{1}.L-bp12-bp13++bn12+bn13)'*K{1}.test'+1/O(2,:)*(a2.*K{2}.L-bp23+bn23)'*K{2}.test'+1/O(3,:)*(a3.*K{3}.L)'*K{3}.test';            
                   if(d(cvtest,:)>=0)
                        Yu(cvtest,:)=1;
                   else
                        Yu(cvtest,:)=-1;
                   end
 end
pre=sum(abs(Yt-xte{1}.L)<0.5)/length(Yt);
ac=sum(abs(Yu-utr{1}.L)<0.5)/length(Yu);
p=[w1;w2;w3];
p=p/2;


