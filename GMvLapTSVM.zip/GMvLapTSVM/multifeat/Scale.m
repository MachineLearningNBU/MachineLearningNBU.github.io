function Scale

view{1,1} = 'fou'; % 200 * 76
view{2,1} = 'kar'; % 200 * 64
view{3,1} = 'fac'; % 200 * 216
view{4,1} = 'pix'; % 200 * 240
view{5,1} = 'zer'; % 200 * 47
view{6,1} = 'mor'; % 200 * 6

for v = 1:6
X = load(['mfeat-',view{v,1},'.txt']);
[nSmp,nFea] = size(X);
for i = 1:nFea
     X(:,i) = X(:,i) ./ max(1e-12,norm(X(:,i)));
end
dlmwrite([view{v,1},'.scaled.txt'],X,'-append','delimiter','\t');
end

