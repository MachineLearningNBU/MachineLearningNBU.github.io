%funLapSVM_Rg.m
%Shiliang Sun, 2010-6-27, 2011-1-16, 2012-3-30

function [p,q,pre,ac]=GMvLapTSVM(xtr,utr,xte,O,c1,c2,c3)

M=size(xtr,2);
type=1;
sigma=1;
for i=1:M
    K{i}.A=makekernel(xtr{i}.A,[xtr{i}.data;utr{i}.data],type,sigma);
    K{i}.K=makekernel([xtr{i}.data;utr{i}.data],[xtr{i}.data;utr{i}.data],type,sigma);
    K{i}.U=makekernel(utr{i}.data,[xtr{i}.data;utr{i}.data],type,sigma);
    K{i}.Ker=[K{i}.K ones(size(K{i}.K,1),1)];
    K{i}.A=[K{i}.A ones(size(K{i}.A,1),1)];
    K{i}.B=makekernel(xtr{i}.B,[xtr{i}.data;utr{i}.data],type,sigma);
    K{i}.B=[K{i}.B ones(size(K{i}.B,1),1)];
    K{i}.L=xtr{i}.L;
    K{i}.test=makekernel(xte{i}.data,[xtr{i}.data;utr{i}.data],type,sigma);
end
% E1=[(2*r1+O(1,:))*K{1}.A'*K{1}.A -r1*K{1}.A'*K{2}.A -r1*K{1}.A'*K{3}.A; -r1*K{2}.A'*K{1}.A (2*r1+O(2,:))*K{2}.A'*K{2}.A -r1*K{2}.A'*K{3}.A;-r1*K{3}.A'*K{1}.A -r1*K{3}.A'*K{2}.A (2*r1+O(3,:))*K{3}.A'*K{3}.A];
for i=1:M
bandwidth{i}.b=mean(std([xtr{i}.data; utr{i}.data],0,1));  
L{i}.L=laplacianSun2([xtr{i}.data; utr{i}.data],6,bandwidth{i}.b);
J{i}.T=O(i,:)*K{i}.A'*K{i}.A+c2*O(i,:)*K{i}.Ker'*L{i}.L*K{i}.Ker+c3*K{i}.B'*K{i}.B+2*c1*K{i}.Ker'*K{i}.Ker;  
J{i}.R=O(i,:)*K{i}.B'*K{i}.B+c2*O(i,:)*K{i}.Ker'*L{i}.L*K{i}.Ker+c3*K{i}.A'*K{i}.A+2*c1*K{i}.Ker'*K{i}.Ker; 
J{i}.T=(J{i}.T+J{i}.T')/2;
J{i}.R=(J{i}.R+J{i}.R')/2;
end    
 
E1=[J{1}.T -c1*K{1}.Ker'*K{2}.Ker -c1*K{1}.Ker'*K{3}.Ker; -c1*K{2}.Ker'*K{1}.Ker J{2}.T -c1*K{2}.Ker'*K{3}.Ker;-c1*K{3}.Ker'*K{1}.Ker -c1*K{3}.Ker'*K{2}.Ker J{3}.T];
E1=(E1+E1')/2;

F1=blkdiag(K{1}.B,K{2}.B,K{3}.B);
F2=blkdiag(K{1}.A,K{2}.A,K{3}.A);
% E2=[(2*r1+O(1,:))*K{1}.B'*K{1}.B -r1*K{1}.B'*K{2}.B -r1*K{1}.B'*K{3}.B; -r1*K{2}.B'*K{1}.B (2*r1+O(2,:))*K{2}.B'*K{2}.B -r1*K{2}.B'*K{3}.B;-r1*K{3}.B'*K{1}.B -r1*K{3}.B'*K{2}.B (2*r1+O(3,:))*K{3}.B'*K{3}.B];
E2=[J{1}.R -c1*K{1}.Ker'*K{2}.Ker -c1*K{1}.Ker'*K{3}.Ker; -c1*K{2}.Ker'*K{1}.Ker J{2}.R -c1*K{2}.Ker'*K{3}.Ker;-c1*K{3}.Ker'*K{1}.Ker -c1*K{3}.Ker'*K{2}.Ker J{3}.R];
E2=(E2+E2')/2;

if rank(E1)<size(E1,1)-0.5
    temp625=max(eig(E1));
    E1=E1+temp625*(1e-5)*eye(size(E1)); %for numerical stability, full rank
end
CholFa=chol(E1); 
InvE1=CholFa\(CholFa'\eye(size(E1)));

if rank(E2)<size(E2,1)-0.5
    temp625=max(eig(E2));
    E2=E2+temp625*(1e-5)*eye(size(E2)); %for numerical stability, full rank
end
CholFa=chol(E2); 
InvE2=CholFa\(CholFa'\eye(size(E2)));

e1=ones(size(F1',1),1);
e2=ones(size(F2',1),1);






n1=3*size(K{i}.B,1);
n2=3*size(K{i}.A,1);
e1=ones(n1,1);
e2=ones(n2,1);
n=size(K{1}.B,2)-1;

w=-c3*InvE1*F1'*e1;
w1=w(1:n,:);
p1=w(n+1,:);
w2=w(n+2:2*n+1,:);
p2=w(2*n+2,:);
w3=w(2*n+3:3*n+2,:);
p3=w(3*n+3,:);
u=c3*InvE2*F2'*e2;
u1=u(1:n,:);
q1=u(n+1,:);
u2=u(n+2:2*n+1,:);
q2=u(2*n+2,:);
u3=u(2*n+3:3*n+2,:);
q3=u(3*n+3,:);

nn=size(K{1}.test,1);
 for cvtest=1:nn
        d1=O(1,:)*abs(K{1}.test*w1+p1)/sqrt(w1'*K{1}.K*w1)+O(2,:)*abs(K{2}.test*w2+p2)/sqrt(w2'*K{2}.K*w2)+O(3,:)*abs(K{3}.test*w3+p3)/sqrt(w3'*K{3}.K*w3);
        d2=O(1,:)*abs(K{1}.test*u1+q1)/sqrt(u1'*K{1}.K*u1)+O(2,:)*abs(K{2}.test*u2+q2)/sqrt(u2'*K{2}.K*u2)+O(3,:)*abs(K{3}.test*u3+q3)/sqrt(u3'*K{3}.K*u3);
                   if(d1(cvtest,:)>=d2(cvtest,:))
                        Yt(cvtest,:)=-1;
                   else
                        Yt(cvtest,:)=1;
                   end
 end
pre=sum(abs(Yt-xte{1}.L)<0.5)/length(Yt);

tt=size(utr{1}.data,1);

 for cvtest=1:tt
        d1=O(1,:)*abs(K{1}.U*w1+p1)/sqrt(w1'*K{1}.K*w1)+O(2,:)*abs(K{2}.U*w2+p2)/sqrt(w2'*K{2}.K*w2)+O(3,:)*abs(K{3}.U*w3+p3)/sqrt(w3'*K{3}.K*w3);
        d2=O(1,:)*abs(K{1}.U*u1+q1)/sqrt(u1'*K{1}.K*u1)+O(2,:)*abs(K{2}.U*u2+q2)/sqrt(u2'*K{2}.K*u2)+O(3,:)*abs(K{3}.U*u3+q3)/sqrt(u3'*K{3}.K*u3);
                   if(d1(cvtest,:)>=d2(cvtest,:))
                        Yu(cvtest,:)=-1;
                   else
                        Yu(cvtest,:)=1;
                   end
 end
ac=sum(abs(Yu-utr{1}.L)<0.5)/length(Yu);
% p=[norm(K{1}.A*[w1;p1])^2/(w1'*K{1}.K*w1);norm(K{2}.A*[w2;p2])^2/(w2'*K{2}.K*w2);norm(K{3}.A*[w3;p3])^2]/(w3'*K{3}.K*w3);
% q=[norm(K{1}.B*[u1;q1])^2/(u1'*K{1}.K*u1);norm(K{2}.B*[u2;q2])^2/(u2'*K{2}.K*u2);norm(K{3}.B*[u3;q3])^2]/(u3'*K{3}.K*u3);
p=[norm(K{1}.A*[w1;p1])^2+c2*[w1;p1]'*K{1}.Ker'*L{1}.L*K{1}.Ker*[w1;p1];norm(K{2}.A*[w2;p2])^2+c2*[w2;p2]'*K{2}.Ker'*L{2}.L*K{2}.Ker*[w2;p2];norm(K{3}.A*[w3;p3])^2+c2*[w3;p3]'*K{3}.Ker'*L{3}.L*K{3}.Ker*[w3;p3]];
q=[norm(K{1}.B*[u1;q1])^2+c2*[w1;p1]'*K{1}.Ker'*L{1}.L*K{1}.Ker*[w1;p1];norm(K{2}.B*[u2;q2])^2+c2*[w2;p2]'*K{2}.Ker'*L{2}.L*K{2}.Ker*[w2;p2];norm(K{3}.B*[u3;q3])^2+c2*[w3;p3]'*K{3}.Ker'*L{3}.L*K{3}.Ker*[w3;p3]];
