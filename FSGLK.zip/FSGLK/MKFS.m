function [W,obj]=MKFS(fea,alpha,gamma,lambda,pnorm,phi,n,lv,c,dimension)
[v1,v2]=size(fea);
Zv=cell(v1,v2);
Kv=cell(v1,v2);
Dv=cell(v1,v2);
V=rand(n,c);
W=rand(dimension,c);

lb=zeros(v2,1);
MaxIter=20;

nFea=zeros(1,v2);
M = cell(1,v2);
J = cell(1,v2);


G=rand(dimension,dimension);
X_bar = [];
%delta_sum=0;
for num = 1:lv
    X_bar = [X_bar,fea{num}];
end  

for num = 1:lv
    Zv{num}=rand(n,n);
    t_values=1.5;
    tmp = EuDist2(fea{num}, [], 0);
    d_max = max(tmp(:));
    Kv{num} = exp(-tmp ./ (t_values * d_max^2));
    Diag_Kv{num} = diag(Kv{num});
    Dv{num} = Diag_Kv{num} * ones(1,n) + ones(n, 1) * Diag_Kv{num}' - 2 * Kv{num};
    M{num} = zeros(n,n);  
    J{num} = zeros(n,n);  
    nFea(1,num)=size(fea{1,num},2);
end

objZ=0;
Zmt=0;
Zm=0;
for num = 1:lv
    Zm=Zm+Zv{num};
    Zmt=Zmt+Zv{num};
end  
  

rho=0.3*n; 
max_rho = 10e12; 
pho_rho =1.3;
eps_val = 1e-8;  

options.Display = 'off';

for iter=1:MaxIter
    
    %%update W 
    W=(gamma*X_bar'*X_bar+lambda*G)\(gamma*X_bar'*V);
    Wi=sqrt(sum(W.*W,2)+eps_val);
    diagonal=(pnorm/2).*(Wi.^(pnorm-2));
    G=diag(diagonal); 
    
       
    % update Zv
    for num = 1:lv
        temp = (2*Kv{num}+((rho+2)*eye(n)))\(2*Kv{num}+rho*J{num}+M{num}-phi*Dv{num}+2*V*V');
        Zv{num} = temp - temp.*eye(n);
        Zv{num} = Zv{num} - diag(diag(Zv{num}));
        for ii = 1:size(Zv{num},2)
            idx= 1:size(Zv{num},2);
            idx(ii) = [];
            Zv{num}(ii,idx) = EProjSimplex_new(Zv{num}(ii,idx));
        end
    end
   
    
    %%update V
    
   temp1=Zmt*V+Zm*V+gamma*X_bar*W;
   temp2=2*lv*V*V'*V+gamma*V;
   temp2(temp2 == 0) = eps;
   temp3=temp1./temp2;
   V=(V.*temp3).^(1/4);
    

    %% update G
    Z_tensor = cat(3, Zv{:,:});
    M_tensor = cat(3, M{:,:});
    temp_Z = Z_tensor(:);
    temp_M = M_tensor(:);
    zX = [n, n, lv];
    %twist-version
    [j, objZ] = Gshrink(temp_Z + 1/rho*temp_M,(n*alpha)/rho,zX,0,3);
    J_tensor = reshape(j, zX);
    %5 update M
    temp_M = temp_M + rho*(temp_Z - j);
    %record the iteration information
    history.objval(iter+1) = objZ;
    
   
    sumobj44=0;
       for num = 1:lv
           sumobj44=sumobj44+trace(Kv{num}-2*Kv{num}*Zv{num}+Zv{num}'*Kv{num}*Zv{num});
           %sumobj44=sumobj44+trace(Zv{num}'*Dv{num});
           sumobj44=sumobj44+phi*trace(Zv{num}'*Dv{num});
           %sumobj44=sumobj44+(Bv(num)^delta)*norm(Zv{num}-V*V','fro')^2;
           sumobj44=sumobj44+norm(Zv{num}-V*V','fro')^2;
       end
       sumobj44=sumobj44+alpha*objZ+gamma*norm(X_bar*W-V,'fro')^2+lambda*trace(W'*G*W);
       obj(iter)=sumobj44;
       if iter >= 2 && (abs(obj(iter)-obj(iter-1)/obj(iter))<eps)
          break;
       end   
       disp(iter);
end   
end