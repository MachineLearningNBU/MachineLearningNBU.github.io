function [Hv,obj]=dai(fea,alpha,beta,v,c)
[v1,v2]=size(fea);
Uv=cell(v1,v2);
Vv=cell(v1,v2);
Hv=cell(v1,v2);
Sv=cell(v1,v2);
Cv=cell(v1,v2);
Gv=cell(v1,v2);
Dv=cell(v1,v2);
Ls=cell(v1,v2);
d=zeros(v2,1);
tS=cell(v1,v2);
gamma=cell(v1,v2);
a=zeros(v2,1);
miu=zeros(v2,1);
num_X=size(fea{1},1);
r=rand(num_X,num_X);
num_view=size(fea,2);
MaxIter=20;
U=rand(num_X,num_X);
Y=randn(num_X,c);
k=c;
R=cell(v1,v2);
rho=0.3*num_X;max_rho = 10e12; pho_rho =1.2;zeka=1.6;
objV=0;
Rho1=cell(v1,v2);
Rho1=cell(v1,v2);
V=rand(num_X,c);
for num = 1:v
    fea{num}=fea{num}';
    d(num)=size(fea{num},1);
    Uv{num}=rand(d(num),k);
    Vv{num}=rand(k,num_X);
    Hv{num}=rand(d(num),c);
    Dv{num}=eye(d(num));
    Cv{num}=rand(num_X,num_X);
    Sv{num} = constructW_PKN(fea{num}, 5, 1);
    Zv{num} = constructW_PKN(fea{num}, 5, 1);
    Gv{num}=zeros(num_X,num_X);
    R{num} = zeros(num_X,num_X);
    Rho1{num}=zeros(d(num),num_X);
    Rho2{num}=zeros(num_X,num_X);
    gamma{num}=1/v;
    a(num)=1/v;
    miu(num)=1/norm(U-Cv{num},'fro');
    %Ssum=Ssum+Sv{num};
end

for iter=1:MaxIter
    %update a
    temp=0;
    L=zeros(num_X,num_X);
    for num=1:v
        Ls{num} = full(diag(sum(Sv{num},2))-Sv{num});
        L=L+a(num)*Ls{num};
        temp=temp+trace(Y'*Ls{num}*Y);
    end
    for num=1:v
        a(num)=(trace(Y'*Ls{num}*Y))./temp;
    end
    temp1=0;
    temp2=0;
    %%update Uv
    for num = 1:v
        temp1=2*r*V*V'+2*miu(num)*Cv{num};
    end
    temp2=2*r*v+2*miu(num)*Cv{num};
    U=U.*(temp1./temp2);
    %%update V
    for num = 1:v
        temp1=fea{num}'*Hv{num};
    end
    temp1=temp1+U*V+U'*V;
    temp2=v*V+2*V*V'*V;
    V=V.*(temp1./temp2);
    %%update Hv
    for num = 1:v
        %Hv{num}=((a{num}^2)*fea{num}*fea{num}'+lambda*Dv{num})\(a{num}*fea{num}*Y);
        Hv{num}=(fea{num}*fea{num}'+beta*Dv{num})\(fea{num}*Y);
        Hi=sqrt(sum(Hv{num}.*Hv{num},2)+eps);
        diagonal=0.5./Hi;
        Dv{num}=diag(diagonal);
    end
    %%update E
    %%1.update E1
    for num=1:v
        A1=fea{num}-fea{num}*Zv{num}-Rho1{num}/rho;
        E{num}=compute_E(A1, beta, rho);
    end
    %update C
    f=ones(v,1)/v;
    R=rand(v,v);
    Q=R-f*f'+diag(f);
    W=cell(v,1);
    for i=1:v
        W{i}=f(i)*U'*Zv{i};
    end
    C=cell(v,1);
    for i=1:v
        C{i}=W{i};
        C{i}=max(C{i},0);
        C{i}=min(C{i},Zv{i});
    end
    %%update Zv
    temp=0;
     for i=1:v
        temp=temp+R(i,i)*f(i)*f(i);
    end
    for num = 1:v
        A=E{num}-fea{num}+Rho1{num}/rho;
        B=Sv{num}-Rho2{num}/rho;
        Zv{num}=(eye(num_X)+rho*fea{num}'*fea{num})\(rho*B-2*fea{num}'*A-temp*(Zv{num}-C{num}));
    end
    S_tensor = cat(3, Zv{:,:});
    R_tensor = cat(3, Rho2{:,:});
    temp_S = S_tensor(:);
    temp_R = R_tensor(:);

    sX = [num_X, num_X, num_view];
    %twist-version
    [g, objV] = wshrinkObj(temp_S + 1/rho*temp_R,(num_X*alpha)/rho,sX,0,3)   ; %%%%%%%%

    G_tensor = reshape(g,sX);
    %5 update R
    temp_R = temp_R + rho*(temp_S - g);

    R_tensor = reshape(temp_R,sX);
    %6 update G
    for v=1:v
        Gv{v} = G_tensor(:,:,v);
        Rho2{v} = R_tensor(:,:,v);
    end
    rho = min(rho*pho_rho, max_rho);
    
    sumobj=0;
    for num=1:num_view
        L3=norm(fea{num}'*Hv{num}-V,"fro")^2;
        L4=beta*trace(Hv{num}'*Dv{num}*Hv{num});
        L2=norm(E{num},"fro")^2;
        L1=norm(U-V*V',"fro")^2;
        %L6=rho/2*norm(fea{num}-Pv{num}*H-E2{num}+Rho2{num}/rho,"fro")^2
        sumobj=sumobj+L3+L4+L2+L1;
    end
    sumobj=sumobj+objV;
    obj(iter)=real(sumobj);
    if iter >= 2 && (abs(obj(iter)-obj(iter-1)/obj(iter))<eps)
        break;
    end


    
end
end
