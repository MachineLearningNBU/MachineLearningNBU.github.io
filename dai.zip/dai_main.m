clc;clear all;

% addpath('C:\Users\think\Desktop\AIpaper\mymymy!\paper6all\codes666\usingdatasets');
addpath('C:\Users\daiji\Desktop\code\mycode\Multi-view-datasets-master');

% addpath('C:\Users\think\Desktop\AIpaper\mymymy!\paper6all\codes666\util');
addpath('C:\Users\daiji\Desktop\code\mycode\util');
a='NUS';

% filename=['C:\Users\think\Desktop\AIpaper\mymymy!\paper6all\codes666\results\ours\',a,'.mat'];
filename=['C:\Users\daiji\Desktop\code\mycode\Multi-view-datasets-master\',a,'.mat'];
load(a);

[~,v]=size(fea);
n=size(fea{1},1);
class_num=size(unique(gt),1);
label=gt;
dimension=0;
for num = 1:v
    dimension=dimension+size(fea{num},2);
    min_val = min(fea{num}(:));
    max_val = max(fea{num}(:));
    fea{num}=(fea{num} - min_val) / (max_val - min_val);
end

feanum=[10:10:300]; % feature dimension

ACC=[];
NMI=[];
ACCstd=[]; 
NMIstd=[];
Fscore=[];
Fscorestd=[];
Precision=[];
Precisionstd=[];
Recall=[];
Recallstd=[];
ARI=[];
ARIstd=[];
rankmvufs=[];
mvufsobj=[];

alpha=[1e-2,1e-1,1,1e1,1e2];
% alpha=1;
% beta=1;
%lambda=1;
% gamma=1;
%keze=1;
beta=[1e-2,1e-1,1,1e1,1e2];
%lambda=[1e-2,1e-1,1,1e1,1e2];
%gamma=[1e-2,1e-1,1,1e1,1e2];
%keze=[1e-2,1e-1,1,1e1,1e2];
iter=0;

for i=1:size(alpha,2)
for o=1:size(beta,2)
%[P,obj]=CDMvFS(fea,alpha(i),beta(o),gamma(l),n,v,class_num);
[P,obj]=dai(fea,alpha(i),beta(o),v,class_num);
%[P,obj]=One(fea,alpha(i),beta(o),lambda(l),v,class_num);
iter=iter+1;

allP=[];
X=[];
for num = 1:v
    allP=[allP;P{num}];
    X=[X,fea{num}];
end

W1 = [];
for m = 1:dimension
    W1 = [W1 norm(allP(m,:),2)];
end
%% test stage
[~,index] = sort(W1,'descend');
rankmvufs(:,iter)=index;
mvufsobj(1:size(obj,2),iter)=obj;

for j = 1:length(feanum)
acc=[];
nmi=[];
fscore=[];
precision=[];
recall=[];
ari=[];
for k = 1:20
    new_fea = X(:,index(1:feanum(j)));
    idx = kmeans(new_fea, class_num,'MaxIter',200);
    res = bestMap(label,idx);
    acc111 = length(find(label == res))/length(label); % calculate ACC 
    nmi111 = MutualInfo(label,idx); % calculate NMI
    [f111,p111,r111] = compute_f(label,idx);
    [ar111,~,~,~]=RandIndex(label,idx);
    acc=[acc;acc111];
    nmi=[nmi;nmi111];
    fscore=[fscore;f111];
    precision=[precision;p111];
    recall=[recall;r111];
    ari=[ari;ar111];
end
ACC=[ACC;sum(acc)/20];
ACCstd=[ACCstd;std(acc)];
NMI=[NMI;sum(nmi)/20];
NMIstd=[NMIstd;std(nmi)];
Fscore=[Fscore;sum(fscore)/20];
Fscorestd=[Fscorestd;std(fscore)];
Precision=[Precision;sum(precision)/20];
Precisionstd=[Precisionstd;std(precision)];
Recall=[Recall;sum(recall)/20];
Recallstd=[Recallstd;std(recall)];
ARI=[ARI;sum(ari)/20];
ARIstd=[ARIstd;std(ari)];
end

end
end
number=size(ACC,1);
final=zeros(number,4);
maxACC=0;
maxACC_index=0;
maxNMI=0;
maxNMI_index=0;
maxARI=0;
maxARI_index=0;
maxFscore=0;
maxFscore_index=0;
maxPrecision=0;
maxPrecision_index=0;
maxRecall=0;
maxRecall_index=0;
for j=1:number
    final(j,1:12)=[ACC(j,1),ACCstd(j,1),NMI(j,1),NMIstd(j,1),ARI(j,1),ARIstd(j,1),Fscore(j,1),Fscorestd(j,1),Precision(j,1),Precisionstd(j,1),Recall(j,1),Recallstd(j,1)];
    if ACC(j,1)>maxACC
            maxACC=ACC(j,1);
            maxACC_index = j;
    end
    
    if NMI(j,1)>maxNMI
            maxNMI=NMI(j,1);
            maxNMI_index = j;
    end
    
    if ARI(j,1)>maxARI
            maxARI=ARI(j,1);
            maxARI_index = j;
    end
    if Fscore(j,1)>maxFscore
            maxFscore=Fscore(j,1);
            maxFscore_index = j;
    end
    if Precision(j,1)>maxPrecision
            maxPrecision=Precision(j,1);
            maxPrecision_index = j;
    end
    if Recall(j,1)>maxRecall
            maxRecall=Recall(j,1);
            maxRecall_index = j;
    end
end

[newvalue,endindex]=sort(ACC,'descend');

final(endindex(1:10),:);
fprintf('ACC:%4.2f+%4.2f\n',maxACC*100,ACCstd(maxACC_index,1)*100);
fprintf('NMI:%4.2f+%4.2f\n',maxNMI*100,NMIstd(maxNMI_index,1)*100);
fprintf('ARI:%4.2f+%4.2f\n',maxARI*100,ARIstd(maxARI_index,1)*100);
fprintf('Fscore:%4.2f+%4.2f\n',maxFscore*100,Fscorestd(maxFscore_index,1)*100);
fprintf('Precision:%4.2f+%4.2f\n',maxPrecision*100,Precisionstd(maxPrecision_index,1)*100);
fprintf('Recall:%4.2f+%4.2f\n',maxRecall*100,Recallstd(maxRecall_index,1)*100);
% save(filename);
