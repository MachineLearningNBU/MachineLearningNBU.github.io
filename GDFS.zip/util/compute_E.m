function [E] = compute_E(Q, lambda, mu)
    % 获取矩阵 Q 的列数
    [m, n] = size(Q);
    E = zeros(m, n);
    % 计算阈值
    threshold = lambda / mu;

    % 遍历每一列
    for j = 1:n
        % 计算当前列的 L2 范数
        norm_Q_j = norm(Q(:, j), 2);

        % 判断 L2 范数是否大于阈值
        if norm_Q_j > threshold
            % 计算缩放因子
            scale_factor = (norm_Q_j - threshold) / norm_Q_j;
            % 计算 E 的当前列
            E(:, j) = scale_factor * Q(:, j);
        else
            % 否则 E 的当前列为零（默认初始化已经是零）
            E(:, j) = zeros(m, 1);  % 更新为零列
        end
    end
end
