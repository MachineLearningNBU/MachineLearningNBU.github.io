%%Flexible structure with consensus information for multi-view feature selection
function [Wv,obj]=GDFS(fea,alpha,beta,gamma,Rho,n,v,c)
[v1,v2]=size(fea);
Zv=cell(v1,v2);
Kv=cell(v1,v2);
Diag_Kv=cell(v1,v2);
% seed = 109612;
% randn('seed',seed), rand('seed',seed);
Wv=cell(v1,v2);
Sv=cell(v1,v2);
Dv=cell(v1,v2);
D=cell(v1,v2);
P=ones(v2,v2);
Q=ones(v2,1);
d=zeros(v2,1);
Aeq=ones(1,v2);
Beq=1;
lb=zeros(v2,1);
MaxIter=20; %%30�ֲ���ˣ�100�ֲ���Ч��
% rho = 0.1*n;
rho = 0.1;
Ssum=0;
Localsum=cell(v1,v2);
 %%% W D
Ls=cell(1,v2);

for num = 1:v
    Zv{num}=rand(n,n);
    
    t_values=1.5;
   % ����ŷ�Ͼ������
    tmp = EuDist2(fea{num}, [], 0);
    
    % ���������� d_max
    d_max = max(tmp(:));
    
    % �����˹�˾���
    Kv{num} = exp(-tmp ./ (t_values * d_max^2));


    % ����ԽǾ��� Diag(K)
    Diag_Kv{num} = diag(Kv{num});
    % ����������� D^x
    Dv{num} = Diag_Kv{num} * ones(1, n) + ones(n, 1) * Diag_Kv{num}' - 2 * Kv{num};
    M{num} = zeros(n,n);  %Lagrange multiplier
    J{num} = zeros(n,n);  % variable S
end

for num = 1:v
    fea{num}=fea{num}'; %%dv*n
    d(num)=size(fea{num},1); %%dv
    Wv{num}=randn(d(num),c); %%Hά�ȿ��Ը�
    D{num}=eye(d(num));
    Sv{num} = constructW_PKN(fea{num}, 5, 1);
    Ssum=Ssum+Sv{num};

%     
%    
%     tS{num} = Sv{num}; %%%%%%%%%%%%%%%%%%%%%
%     A0=[];
%     A0=tS{num};
%     Ls{num} = full(diag(sum(A0,2))-A0);  %diag�����ԽǾ���������˹���� L
end
sX = [n, n, v];
V=2*full(sqrt(mean(mean(Ssum))/c))*rand(n,c);
rho=0.3*n; 
max_rho = 10e12; 
pho_rho =1.3;
eps_val = 1e-8;  % ����Ϊ�ʺϵ�ֵ

for iter=1:MaxIter

    % update Zv
    for num = 1:v
        temp = Sv{num}-Rho*Dv{num}/beta;
        Zv{num} = temp - temp.*eye(n);
        Zv{num} = Zv{num} - diag(diag(Zv{num}));
        for ii = 1:size(Zv{num},2)
            idx= 1:size(Zv{num},2);
            idx(ii) = [];
            Zv{num}(ii,idx) = EProjSimplex_new(Zv{num}(ii,idx));
        end
    end
    
    %%update V
    sumwS=0;
    for num = 1:v
        sumwS = sumwS+2*Sv{num};
    end
    [V,~,~]=eig1(eye(n)-sumwS,c,0);
    
    % update Sv
    for num = 1:v
        sumSw=0;
        for num2 = 1:v
            if num2==num
                continue
            end
            sumSw=sumSw+Sv{num2};
        end
        intermedia=fea{num}'*Wv{num}*Wv{num}'*fea{num};
        
        temp =(2*intermedia+(2+rho+beta)*eye(n))\(2*(intermedia+V*V'-sumSw)+beta*Zv{num}+rho*J{num}-M{num});
        Sv{num} = temp - temp.*eye(n);
         %%-projection
        Sv{num} = Sv{num} - diag(diag(Sv{num}));
        for ii = 1:size(Sv{num},2)
            idx= 1:size(Sv{num},2);
            idx(ii) = [];
            Sv{num}(ii,idx) = EProjSimplex_new(Sv{num}(ii,idx));
        end
 
    end
    
    
    
    
    %%update Wv
    for num = 1:v
        LG = (eye(n) - Sv{num});
        LG = LG * LG'; % ת���ɰ���������
        LG = (LG + LG') / 2;
        LL = LG;
        [Y, ~, ~]=eig1(LL, c, 0);   % ���� LG �� c ����С����ֵ��Ӧ����������������Щ�������������� Y ��, eig1 ����������ȡ��Щ����ֵ������������
       %%solve ||Y-XtH||F+alpha||H||21
        Wv{num}=(fea{num}*fea{num}'+gamma*D{num})\(fea{num}*Y);
        Hi=sqrt(sum(Wv{num}.*Wv{num},2)+eps);
        diagonal=0.5./Hi;
        D{num}=diag(diagonal);
    end
    
    
    %% update J
    Z_tensor = cat(3, Zv{:,:});
    M_tensor = cat(3, M{:,:});
    temp_Z = Z_tensor(:);
    temp_M = M_tensor(:);
    zX = [n, n, v];
    %twist-version
    [j, objZ] = Gshrink(temp_Z + 1/rho*temp_M,(n*alpha)/rho,zX,0,3);
    J_tensor = reshape(j, zX);
    %5 update M
    temp_M = temp_M + rho*(temp_Z - j);
    %record the iteration information
    history.objval(iter+1) = objZ;
    

    sumobj=0;
    sumwS=0;
    for num = 1:v
        sumwS = sumwS +Sv{num};
    end
    for num = 1:v
       sumobj=sumobj+0.5*beta*norm(Sv{num}-Zv{num},'fro').^2+gamma*trace(Wv{num}'*D{num}*Wv{num})+norm(Wv{num}'*fea{num}-Wv{num}'*fea{num}*Sv{num},'fro')^2+Rho*trace(Zv{num}'*Dv{num});
    end
    sumobj=sumobj+norm(sumwS-V*V','fro').^2+alpha*objZ;
    obj(iter)=sumobj;
    if iter >= 2 && (abs(obj(iter)-obj(iter-1)/obj(iter))<eps)
        break;
    end
    
    disp(iter);
end
plot(obj,'b-*');
end

