% 1.初始化和加载数据
clc;clear all;

addpath('usingdatasets');

addpath('util');

% a='yale.mat';
a='outdoor_scene_new.mat';
% a='BBCSport.mat';
% a='Handwritten.mat';
% a='3sources.mat';
% a='WebKB.mat';
% a='Caltech101-7.mat';
% a='MSRC_v1.mat';

filename=['results\ours\',a,'(2016b)_4.mat'];



load(a);
[~,v]=size(fea);
n=size(fea{1},1);
class_num=size(unique(gt),1);
label=gt;

% 2.参数和变量初始化
dimension=0;
for num = 1:v
    dimension=dimension+size(fea{num},2);
end

feanum=[10:10:300]; % feature dimension,定义要选择的特征数量的集合，从 10 到 300

ACC=[];
NMI=[];
ACCstd=[];
NMIstd=[];
Fscore=[];
Fscorestd=[];
Precision=[];
Precisionstd=[];
Recall=[];
Recallstd=[];
ARI=[];
ARIstd=[];
rankmvufs=[];
mvufsobj=[];

% 
% alpha=[1e-2,1e-1,1,1e1,1e2];
% beta=[1e-3,1e-2,1e-1,1,1e1,1e2,1e3];
% gamma=[1e-3,1e-2,1e-1,1,1e1,1e2,1e3];
% beta=[1e-3,1e-2,1e-1,1,1e1,1e2,le3];
% gamma=[1e-3,1e-2,1e-1,1,1e1,1e2,le3];
alpha=1;
beta=1;
gamma=1;
% alpha=[1e-3,1,1e3];
% beta=[1e-4,1e-2,1,1e2,1e4];
% gamma=[1e-5,1e-3,1e-1,1,1e1,1e3,1e5];

% gamma=[0.001, 0.005, 0.01, 0.05, 0.1, 0.5, 1]; % 超参数
% alpha=1;
% beta=1;
% gamma=1;
% 3.网格搜索与特征选择
% 遍历所有可能的 alpha、beta 和 gamma 组合进行特征选择，调用 CDMvFS 函数，输出特征选择矩阵 P 和目标函数值 obj。
% 结果存储
% result_table = {};
iter=0;
% for i=1:size(alpha,2)
% for o=1:size(beta,2)
% % 计算每个 feanum 的 ACC
% % group_results = {}; % 临时存储当前超参数下的结果
% for s=1:size(gamma,2)


% [P,obj]=new_xyw(fea,alpha(i),beta(o),gamma(s),n,v,class_num);
[P,obj]=new_xyw(fea,alpha,beta,gamma,n,v,class_num);

% 迭代次数（每1轮有一个数据点）
iterations = 1:30;

% 目标函数值（示例数据）
obj_values = obj;

% 画图
figure;
plot(iterations, obj_values, 'b-', 'LineWidth', 2); % 先绘制蓝色折线

% 找到 5, 10, 15, ... 在 iterations 中的索引
marker_positions = [1, 5, 10, 15, 20, 25, 30]; % 需要标记的位置
[found, marker_indices] = ismember(marker_positions, iterations); % 获取索引
marker_indices = marker_indices(found); % 过滤掉找不到的索引

% 只在 5, 10, 15, ... 这些点标记
hold on;
plot(iterations(marker_indices), obj_values(marker_indices), 'bo', 'MarkerSize', 8, 'MarkerFaceColor', 'w');

% 设置坐标轴标签
xlabel('The number of iterations', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('Objective function value', 'FontSize', 14, 'FontWeight', 'bold');

% 设置刻度字体大小
set(gca, 'FontSize', 12, 'LineWidth', 1);

% 添加网格
grid on;

% 自动调整 y 轴范围
ylim([floor(min(obj_values))-1, ceil(max(obj_values))+1]); % 自
% y_min = floor(min(obj_values)) - 1;
% y_max = ceil(max(obj_values)) + 1;
% ylim([115, 120]); 

% 计算 6 个等间距的 y 轴刻度
% yticks(linspace(115,120, 6)); 

hold off;


% 迭代次数（每1轮有一个数据点）

% iter=iter+1
% 
% allP=[];
% X=[];
% for num = 1:v
%     allP=[allP;P{num}]; % allP 聚合了所有视图的特征选择矩阵
%     X=[X,fea{num}]; %X 是所有视图的特征拼接成的大矩阵
% end
% 
% % 4. 特征排序与指标评估
% W1 = [];
% for m = 1:dimension
%     W1 = [W1 norm(allP(m,:),2)];
% end
% 
% %% test stage
% [~,index] = sort(W1,'descend');
% rankmvufs(:,iter)=index;
% mvufsobj(1:size(obj,2),iter)=obj;

% for j = 1:length(feanum) % feanum(j) 表示第 j 次实验所选择的特征数量
% acc=[];
% nmi=[];
% fscore=[];
% precision=[];
% recall=[];
% ari=[];
% for k = 1:20 % 进行 20 次实验，用于后续计算平均值和标准差，以减少实验结果的波动
%     new_fea = X(:,index(1:feanum(j))); % 在 new_fea 上使用 kmeans 进行聚类，簇的数量为 class_num，最大迭代次数为 200。
%     idx = kmeans(new_fea, class_num,'MaxIter',200);
%     res = bestMap(label,idx);
%     acc111 = length(find(label == res))/length(label); % calculate ACC 
%     nmi111 = MutualInfo(label,idx); % calculate NMI 标准互信息
%     [f111,p111,r111] = compute_f(label,idx);
%     [ar111,~,~,~]=RandIndex(label,idx);
%     acc=[acc;acc111];
%     nmi=[nmi;nmi111];
%     fscore=[fscore;f111];
%     precision=[precision;p111];
%     recall=[recall;r111];
%     ari=[ari;ar111];
% end
% ACC=[ACC;sum(acc)/20];
% ACCstd=[ACCstd;std(acc)];
% NMI=[NMI;sum(nmi)/20];
% NMIstd=[NMIstd;std(nmi)];
% Fscore=[Fscore;sum(fscore)/20];
% Fscorestd=[Fscorestd;std(fscore)];
% Precision=[Precision;sum(precision)/20];
% Precisionstd=[Precisionstd;std(precision)];
% Recall=[Recall;sum(recall)/20];
% Recallstd=[Recallstd;std(recall)];
% ARI=[ARI;sum(ari)/20];
% ARIstd=[ARIstd;std(ari)];
% % % 仅在第一行记录 alpha, beta, lambda
% %    if j == 1
% %       group_results = [group_results; {alpha(i), beta(o), gamma(s), feanum(j)}];
% %    else
% %       group_results = [group_results; {[], [], [], feanum(j)}];
% %    end
% % end
% 
% end
% 追加当前超参数组的结果
% result_table = [result_table; group_results];

% end
% end
% end
% excelfile = 'WebKB1.mat(2016b)_ACC.xlsx'; % Excel 文件名
% % 将数据转换为表格并写入 Excel
% T = cell2table(result_table, 'VariableNames', {'alpha', 'beta', 'gamma', 'feanum'});
% writetable(T, excelfile, 'Sheet', 1, 'WriteMode', 'overwrite');
% % 写入 Excel，从 D2 开始
% writematrix(round(ACC,4), excelfile, 'Sheet', 1, 'Range', 'E2');  
% disp('数据已成功写入 Excel 文件！');

% 5. 结果存储与显示
% disp(iter);
% number=size(ACC,1);
% final=zeros(number,4);
% for j=1:number
%     final(j,1:12)=[ACC(j,1),ACCstd(j,1),NMI(j,1),NMIstd(j,1),ARI(j,1),ARIstd(j,1),Fscore(j,1),Fscorestd(j,1),Precision(j,1),Precisionstd(j,1),Recall(j,1),Recallstd(j,1)];
% end
% 
% [newvalue,endindex]=sort(ACC,'descend');
% 
% final(endindex(1:10),:);
% 
% 
% save(filename);
% 
% disp('ACC')
% max(ACC)
% disp('NMI')
% max(NMI)
% disp('ARI')
% max(ARI)
% disp('Fscore')
% max(Fscore)
% disp('Precision')
% max(Precision)
% disp('Recall')
% max(Recall)
% % 
% excelFileName='yale_4.xlsx';
% % excelFileName='outdoor_scene_new.xlsx';
% % excelFileName='BBCSport3.xlsx';
% % excelFileName='Handwritten.xlsx';
% % excelFileName='3sources2.xlsx';
% % excelFileName='WebKB2.xlsx';
% % excelFileName='Caltech101-7.xlsx';
% % excelFileName='MSRC_v1_2.xlsx';
% % 
% % 
% % 假设ACC, NMI, ARI, Fscore, Precision, Recall等是预先定义的数组
% % 需要从这些数组中找到最大值及其下标
% [accMax, accMaxIdx] = max(ACC);  % 找到ACC的最大值及其下标
% [accstdMax] = ACCstd(accMaxIdx);  % 获取对应的ACCstd值
% 
% [nmiMax, nmiMaxIdx] = max(NMI);  % 找到NMI的最大值及其下标
% [nmistdMax] = NMIstd(nmiMaxIdx);  % 获取对应的nmistd值
% [ariMax, ariMaxIdx] = max(ARI);  % 找到ARI的最大值及其下标
% [aristdMax] = ARIstd(ariMaxIdx);
% [fscoreMax, fscoreMaxIdx] = max(Fscore);  % 找到Fscore的最大值及其下标
% [fscorestdMax] = Fscorestd(fscoreMaxIdx);
% [precisionMax, precisionMaxIdx] = max(Precision);  % 找到Precision的最大值及其下标
% [PrecisionstdMax] = Precisionstd(precisionMaxIdx);
% [recallMax, recallMaxIdx] = max(Recall);  % 找到Recall的最大值及其下标
% [recallstdMax] = Recallstd(recallMaxIdx);
% 
% % 记录最大值及其对应的其他指标值
% shuju = [accMax, accstdMax, nmiMax, nmistdMax,ariMax, aristdMax,fscoreMax, fscorestdMax,precisionMax, PrecisionstdMax,recallMax,recallstdMax];  % 数据
% writematrix(shuju,excelFileName);

% shuju=[max(ACC),max(NMI),max(ARI),max(Fscore),max(Precision),max(Recall)];
% datarange=['A', num2str(1), ':L', num2str(1)];
% writematrix(shuju,excelFileName,'Range',datarange);
% 
% data = load('results\ours\yale.mat(2016b).mat'); % 读取 .mat 文件
% [accMax, accMaxIdx] = max(data.ACC);  % 找到ACC的最大值及其下标
% [accstdMax] = data.ACCstd(accMaxIdx);  % 获取对应的ACCstd值
% [nmiMax, nmiMaxIdx] = max(data.NMI);  % 找到NMI的最大值及其下标
% [nmistdMax] = data.NMIstd(nmiMaxIdx);  % 获取对应的nmistd值
% [ariMax, ariMaxIdx] = max(data.ARI);  % 找到ARI的最大值及其下标
% [aristdMax] = data.ARIstd(ariMaxIdx);
% [fscoreMax, fscoreMaxIdx] = max(data.Fscore);  % 找到Fscore的最大值及其下标
% [fscorestdMax] = data.Fscorestd(fscoreMaxIdx);
% [precisionMax, precisionMaxIdx] = max(data.Precision);  % 找到Precision的最大值及其下标
% [PrecisionstdMax] = data.Precisionstd(precisionMaxIdx);
% [recallMax, recallMaxIdx] = max(data.Recall);  % 找到Recall的最大值及其下标
% [recallstdMax] = data.Recallstd(recallMaxIdx);
% 
% % 记录最大值及其对应的其他指标值
% shuju = [accMax, accstdMax, nmiMax, nmistdMax,ariMax, aristdMax,fscoreMax, fscorestdMax,precisionMax, PrecisionstdMax,recallMax,recallstdMax];  % 数据
% writematrix(shuju,excelFileName);

% 
% 
% 
% acc_data = data.ACC;  % 获取 acc 变量 
% % 定义要写入的 Excel 文件
% filename = 'yale.mat(2016b)_ACC.xlsx';  
% 
% % 写入 Excel，从 D2 开始
% writematrix(acc_data, filename, 'Sheet', 1, 'Range', 'E2');  
% disp('数据已成功写入 Excel 文件！');