function DisL2 = distance_L2(DATA)

DisL2=L2_distance(DATA', DATA', 1);    
temp=ones(1,size(DATA,1))*inf;         
DisL2=DisL2+diag(temp);

end