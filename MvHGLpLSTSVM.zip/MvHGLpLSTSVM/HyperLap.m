function  Lap = HyperLap(H,W)

    inds = find(W ~= inf);
    W = W(inds);
    H = H(:, inds);
    
    
    W = diag(W);
    
    Ve = diag(sum(H, 1));  
    
    Ve = diag(1 ./ diag(Ve));             % 超图归一化拉普拉斯算子by Zhou

    Dv = sum((H * W).').';
    NewW = H * W * Ve * H.';
    Dv_I = 1 ./ Dv;
    Dv_I = diag(Dv_I);
    Lap = sqrt(Dv_I) * (diag(Dv) - NewW) * sqrt(Dv_I);
end