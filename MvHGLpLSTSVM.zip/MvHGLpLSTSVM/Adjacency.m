function A = Adjacency(DisL2,NN)

[Y,I]=sort(DisL2,2);                   
A=zeros(size(DisL2));

for ii=1:size(DisL2,1)                
    A(ii,I(ii,1:NN))=1;              
                                    
end

end