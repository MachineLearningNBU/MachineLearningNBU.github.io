function H = Making_VertexEdgeMartix_H(X,Dis,NN)
    A = Adjacency(Dis,NN);    % Calculate adjacency matrix A ( NN nearest neighbors per row)

    N = size(A, 1);  
    need = [];
    row = [];
    EDGE = zeros(1, N + 1);
    bc = [];
    
    for i = 1:N
        seed = A(i,:);
        mem = find(seed == 1) ;
        k = length(mem);
        EDGEtemp = zeros(1, N + 1);
        EDGETT = zeros(1, N + 1);
        p = 0;
        while sum(ismember(mem, EDGEtemp)) ~= length(mem)
            C = nchoosek(mem, k);
            [a, ~] = size(C);
            
            for j = 1:a
                row = C(j, :);
                x = ismember(mem, EDGEtemp);
                y = find(x == 0);
                need = mem(y);
                
                if sum(ismember(need, row)) ~= 0
                    G = [];
                    
                    for ri = 1:length(row)
                        rx = row(ri);
                        
                        for rj = 1:length(row)
                            ry = row(rj);
                            bc = [bc, A(rx, ry)];
                        end
                        
                        YYY = length(G);
                        
                        if length(G) == 0
                            G = [G; bc];
                        else
                            G = [G; bc];
                        end
                        
                        bc = [];
                    end
                    
                    Gn = length(G);
                    Gsum = sum(G(:));
                    
                    if Gsum == (Gn^2 - Gn)
                        Irow = [i, row];
                        index = 0;
                        if p > 0
                            EDGEtemp = [EDGEtemp; EDGETT];
                            
                            while index < length(Irow)
                                EDGEtemp(p+1, index + 1) = Irow(index + 1);
                                index = index + 1;
                            end
                        else
                            while index < length(Irow)
                                EDGEtemp(p+1, index + 1) = Irow(index + 1);
                                index = index + 1;
                            end
                        end
                        p = p + 1;
                    end
                end
            end
            k = k - 1;
        end
        EDGE = [EDGE; EDGEtemp];
    end
    
    [~, un_i, v] = unique(sort(EDGE, 2), 'rows', 'stable');
    X = sort(un_i);
    Hgraph = [];
    
    for hi = 1:length(X)
        ll = EDGE(X(hi), :);
        
        if length(Hgraph) == 0
            Hgraph = ll;
        else
            Hgraph = [Hgraph; ll];
        end
    end
    
    Hgraph = Hgraph(2:length(X),:);
    [a, b] = size(Hgraph);
    H = zeros(a, N);
    
    for i = 1:a
        row = Hgraph(i, :);
        d = find(row == 0);
        
        for di = d
            row(di) = 0;
        end
        
        for rri = row
            if rri ~= 0
                H(i, rri) = 1;
            end
        end
    end
    
    H = H.';
end
