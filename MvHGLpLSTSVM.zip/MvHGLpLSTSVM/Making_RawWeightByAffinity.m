function W = Making_RawWeightByAffinity(AMatrix,AttMat)
    [row, col] = size(AttMat);
    W = zeros(1, col);
    
    for i = 1:col
        ind = find(AttMat(:, i) ~= 0);
        len = length(ind);
        
        if len ~= 1 && len ~= 0
            sum_val = 0;  
            for m = ind.'
                for n = ind.'
                    sum_val = sum_val + exp(-AMatrix(m, n));
                end
            end
            
            W(i) = sum_val / (len * (len - 1));
        else
            W(i) = inf;
        end
    end
    
end