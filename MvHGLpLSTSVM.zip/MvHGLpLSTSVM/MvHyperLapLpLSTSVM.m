function [PredictY ,time]= MvHyperLapLpLSTSVM(TestX,Data,FunPara,knn,p)
tic;

    disp('------------------------------------------------------------------------');
    disp('Generating the Hypergraph');
    kerfPara = FunPara.kerfPara;
    
for i = 1:size(Data.X,2)
    A{i} = Data.X{i}(Data.Y{i} == 1,:);     
    B{i} = Data.X{i}(Data.Y{i} == -1,:);    
    K{i} = Data.X{i};                       
    
    K{i} = kernelfun(Data.X{i},kerfPara);
    A{i} = kernelfun(A{i},kerfPara,Data.X{i});
    B{i} = kernelfun(B{i},kerfPara,Data.X{i});
    

% ----------------------HyperGraph L --------------------------%
    Distance{i} = distance_L2(K{i});                  
    H{i} = Making_VertexEdgeMartix_H(K{i},Distance{i},knn);
    W{i} = Making_RawWeightByAffinity(Distance{i},H{i});
    L{i} = HyperLap(H{i},W{i});
% -------------------------------------------------------------%

    L{i} = (L{i}+L{i}')/2;           
    [V{i}, U{i}] = eig(L{i});        
    
    J{i} = [K{i},ones(size(Data.X{i},1),1)];
    P{i} = U{i}^(1/2) * V{i} * J{i};
                                        
end

viewnum = size(Data.X,2);                

m1 = size(A{1},1);                            
m2 = size(B{1},1);                            
m = size(Data.X{1},1);                        

% n = size(XTrain.X,2);
c1 = FunPara.p1; 
c2 = FunPara.p2; 
c3 = c2; 
c4 = c2;

e1 = ones(m1,1); 
e2 = ones(m2,1); 
kerfPara = FunPara.kerfPara;


eG = [];
eH = [];

z1_size = [];
z2_size = [];

 for i =1 :size(Data.X,2)
    G{i} = [A{i}, e1];                       
    H{i} = [B{i}, e2];                       
    eG = [eG; ones(size(G{i},1),1)];         
    eH = [eH; ones(size(H{i},1),1)];         
    
    z1{i} = zeros(size(A{i}, 2) + 1, 1);     
    z1_size = [z1_size,size(z1{i},1)];
    
    z2{i} = zeros(size(A{i}, 2) + 1, 1);     
    z2_size = [z2_size,size(z2{i},1)];
 end
Z1 = [];
Z2 = [];

for i = 1: viewnum
  Z1 = [Z1; z1{i}];
  Z2 = [Z2; z2{i}];
end

Z1new = ones(size(Z1,1),1);
Z2new = ones(size(Z2,1),1);


iter = 1;
itmax = 20;
eps = 10^-4;

disp('------------------------------------------------------------------------');
disp('Calculate Z1');

while(norm(Z1-Z1new) >= 0.01  && iter <= itmax)  
    Z1 = Z1new;
    C = mat2cell(Z1,z1_size,1);             
    for i = 1:viewnum
        z1{i} = C{i};
    end
    D1=[];
    D2=[];
    D3=[];
    D5=[];
    for i = 1 :viewnum
          D1Temp = [];
          for j = 1:m1
            D1Temp = [D1Temp 1/abs(G{i}(j,:) * z1{i} + eps)^(2 - p)];          
          end
          D1{i} = diag(D1Temp);                                               
          
          D2Temp = [];
          for j = 1:size(G{i},2)
            D2Temp = [D2Temp 1/abs(z1{i}(j) + eps)^(2 - p)];                   
          end
          D2{i} = diag(D2Temp);                                              

          D3Temp = [];
          for j = 1:m2
            D3Temp = [D3Temp 1/abs(H{i}(j,:) * z1{i} +1+ eps)^(2 - p)];        
          end
          D3{i} = diag(D3Temp);                                               

          for j = 1: viewnum
              D4Temp = [];
              for k = 1:m1
                D4Temp = [D4Temp 1/abs(G{i}(k,:)*z1{i} - G{j}(k,:)*z1{j} + eps)^(2 - p)]; 
              end
              D4{i}{j} = diag(D4Temp);                                       
          end

          D5Temp = [];                        
          for j = 1:m
                D5Temp = [D5Temp 1/abs(P{i}(j,:)*z1{i}+eps)^(2-p)];           
          end
          D5{i} = diag(D5Temp);                                               
    end
    %construct matrix D1 D2 D3 and D4 and D5
 
    D1 = blkdiag(D1{:});                                
    D2 = blkdiag(D2{:});            
    D3 = blkdiag(D3{:});           
    D5 = blkdiag(D5{:});            
 
  
   I1 = [];
   for i = 1:viewnum
       ITemp = [];
       for j = 1:viewnum
          if i == j             %对角线上的元素
                DTemp = zeros(size(G{i},2), size(G{i},2));
                k=i;
                if k==1
                    for n = 2:viewnum
                       DTemp = DTemp + G{i}'*D4{k}{n}*G{i};
                    end
                else
                    for n = 1: k-1
                        DTemp = DTemp + G{i}'*D4{n}{k}*G{i};
                    end
                    for n = k+1 :viewnum
                        DTemp = DTemp + G{i}'*D4{k}{n}*G{i};
                    end 
                end
                ITemp = [ITemp  DTemp];
          elseif i<j
                ITemp = [ITemp  -G{i}'*D4{i}{j}*G{j}];
          elseif i>j
                ITemp = [ITemp  -G{i}'*D4{j}{i}*G{j}];
          end
       end
        I1 = [I1; ITemp];
   end

    GG = blkdiag(G{:});
    HH = blkdiag(H{:});
    PP = blkdiag(P{:});

    matr = (GG'* D1*GG + 2*c1*D2 + 2*c2*HH'*D3*HH + 2*c3*I1 + 2*c4*PP'*D5*PP);
    Z1new = -2*c2*matr\HH'*D3*eH;
    iter = iter + 1;

end

disp('------------------------------------------------------------------------');
disp('Calculate Z2');

iter = 1;
while(norm(Z2 - Z2new) >= 0.01 && iter <= itmax)
    Z2 = Z2new;
    C = mat2cell(Z2,z2_size,1);            
    for i = 1:viewnum
        z2{i} = C{i};
    end
    
    E1=[];
    E2=[];
    E3=[];
    E5=[];
    
for i =1 :size(Data.X,2)
      E1Temp = [];
      for j = 1:m2
        E1Temp = [E1Temp 1/abs(H{i}(j,:) * z2{i} + eps)^(2 - p)];         
      end
      E1{i} = diag(E1Temp);                                              
      
      E2Temp = [];
      for j = 1:size(H{i},2)
        E2Temp = [E2Temp 1/abs(z2{i}(j) + eps)^(2 - p)];                   
      end
      E2{i} = diag(E2Temp);                                               
      
      E3Temp = [];
      for j = 1:m1
        E3Temp = [E3Temp 1/abs(-G{i}(j,:) * z2{i} +1+ eps)^(2 - p)];         
      end
      E3{i} = diag(E3Temp);                                               
      
     
      for j = 1: viewnum
          E4Temp = [];
          for k = 1:m2
            E4Temp = [E4Temp  1/abs(H{i}(k,:)*z2{i} - H{j}(k,:)*z2{j} + eps)^(2-p)];   
          end                      
          E4{i}{j} = diag(E4Temp);    % E4ij对角化存放
      end

      E5Temp = [];                        
      for j = 1:m
            E5Temp = [E5Temp 1/abs(P{i}(j,:)*z2{i}+eps)^(2-p)];             
      end
      E5{i} = diag(E5Temp);                                                
      
      
end
    E1 = blkdiag(E1{:});           
    E2 = blkdiag(E2{:});           
    E3 = blkdiag(E3{:});           
    E5 = blkdiag(E5{:});              
    
   I2 = [];
   for i = 1:viewnum
       ITemp = [];
       for j = 1:viewnum
          if i == j   
                ETemp = zeros(size(H{i},2), size(H{i},2));
                k=i;
                if k==1
                    for n = 2:viewnum
                       ETemp = ETemp + H{i}'*E4{k}{n}*H{i};
                    end
                else
                    for n = 1: k-1
                        ETemp = ETemp + H{i}'*E4{n}{k}*H{i};
                    end
                    for n = k+1 :viewnum
                        ETemp = ETemp + H{i}'*E4{k}{n}*H{i};
                    end 
                end
                ITemp = [ITemp, ETemp];
          elseif i>j
              ITemp = [ITemp, -H{i}'*E4{i}{j}*H{j}];
          elseif j>i
              ITemp = [ITemp, -H{i}'*E4{j}{i}*H{j}];
          end

       end
        I2 = [I2; ITemp];
          
   end
  
    
    matr = (HH' * E1 * HH + 2*c1*E2 + 2*c2*GG'*E3*GG + 2*c3*I2 + 2*c4*PP'*E5*PP);
    Z2new = 2*c2*matr\GG'*E3*eG;
    iter = iter + 1;

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Train classifier 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

m3 = size(TestX{1},1);   
e = ones(m3,1);

concateK = [];

for i = 1: size(TestX,2)
     T{i} = [kernelfun(TestX{i},kerfPara,Data.X{i}),e];
     concateK = [concateK, T{i}];
end

% K = [TestX, e];

Z1 = Z1new;
Z2 = Z2new;

time = toc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Predict 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('------------------------------------------------------------------------');
disp('Finish This Runing');

PredictY = sign(abs(concateK*Z2)-abs(concateK*Z1));

