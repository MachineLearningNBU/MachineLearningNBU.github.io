import torch
from torch.utils.data import DataLoader
import torchvision.transforms as transforms
from torchvision import datasets

device = torch.device("cuda:0"if torch.cuda.is_available() else "cpu")



class autoencoder(torch.nn.Module):
    def __init__(self):
        super(autoencoder,self).__init__()
        #encoder
        self.linear1=torch.nn.Linear(784,256)
        self.linear2=torch.nn.Linear(256,128)
        #self.linear3=torch.nn.Linear(256,128) 
        #decoder
        self.dlinear1=torch.nn.Linear(128,784)
        #self.dlinear2=torch.nn.Linear(40,48)
        
        self.norm1=torch.nn.BatchNorm1d(784)
        self.norm2=torch.nn.BatchNorm1d(256)
        self.norm3=torch.nn.BatchNorm1d(128)
        #self.norm4=torch.nn.BatchNorm1d(128)

        self.relu=torch.nn.ReLU()    
    def forward(self,x):
        #encoder
        x=self.norm1(x)
        x=self.relu(self.norm2(self.linear1(x)))
        #x=self.relu(self.norm3(self.linear2(x)))
        x=self.norm3(self.linear2(x))
        #decoder    
        decode=self.dlinear1(x)
        #decode=self.relu(self.dlinear2(decode))
        
        return x,decode

model=autoencoder()
model.to(device)

class SVM(torch.nn.Module):
    def __init__(self):
        super(SVM,self).__init__()
        self.linear1=torch.nn.Linear(128,1)
        self.relu=torch.nn.ReLU()
        
    def forward(self,x):
        
        #x=x.view(x.size(0),512)
        x=self.linear1(x)
        return x
    
svm=SVM()
svm=svm.to(device)

optimizer1=torch.optim.Adam(svm.parameters(),lr=0.01)
optimizer2=torch.optim.Adam(model.parameters(),lr=0.01)


  
def criterion1(weight,y_pred,y_true):
    loss=pow(torch.norm(weight),2)/2+0.1*pow(torch.norm((1-y_true*y_pred)),2)
    return loss

def criterion2(inputs,code):
    loss=pow(torch.norm(inputs-code),2)
    return loss

def pred(y_pred):
    y_pred[y_pred>=0]=1
    y_pred[y_pred<0]=-1
    return y_pred

def change(targets,num):  #不等于一定在第一个，等于放在第二个
    targets[targets!=num]=-1
    targets[targets==num]=1
 
transform=transforms.Compose([transforms.ToTensor(),transforms.Normalize([0.1307], [0.3801])])
train_dataset=datasets.FashionMNIST('.data/fashion-mnist',train=True,transform=transform,download=False)
test_dataset=datasets.FashionMNIST('.data/fashion-mnist',train=False,transform=transform,download=False)
train_loder=DataLoader(dataset=train_dataset,batch_size=(64),shuffle=True)
test_loder=DataLoader(dataset=test_dataset,batch_size=(64),shuffle=False)


for num in range(10):
    for epoch in range(10):
        cor=0
        tol=0
        k=0 #总共24组 最后一组2个样本
        for bach_idx,(inputs,targets) in enumerate(train_loder):
            inputs=inputs.to(device)
            #print(inputs.size())
            targets=targets.to(device)
            inputs=inputs.view(inputs.size(0),784)
            change(targets,num)
            y1,decode=model(inputs)        
            y_pred=svm(y1)
            y_pred=y_pred.squeeze(1)
            loss=torch.mean(criterion1(svm.linear1.weight.data,y_pred,targets))+0.0001*criterion2(inputs, decode)
            optimizer1.zero_grad()
            optimizer2.zero_grad()
            loss.backward()
            optimizer1.step()
            optimizer2.step()
            #print(model.linear3.weight.grad.data)
            cor+=(pred(y_pred)==targets).sum().item()
            tol+=len(targets)
            #if(epoch==14):           
        print('num:',num)
        print('epoch:',epoch)
        acc=cor*100/tol
                #print('cor:{},tol:{}'.format(cor, tol))
        print('准确率：',acc)
        #print(bach_idx)
        
        #print('g',num,epoch,model.linear2.weight.grad.data)
    torch.save(model.state_dict(),'model/model{}.pth'.format(num))
    torch.save(svm.state_dict(),'model/svm{}.pth'.format(num))
    #if num==2:
        #print('i',inputs)
        #n,m=model(inputs)
        #print('wei',model.linear3.weight.data)
        #v=svm(n)
        #print('o',v)
        #print('1',svm.linear1.weight.data)
        #print('2',model.linear2.weight.data)
        #print('3',model.linear3.weight.data)
   
cor=0
tol=0

for bach_idx,(inputs,targets) in enumerate(test_loder):
    inputs=inputs.to(device)
    targets=targets.to(device)
    inputs=inputs.view(inputs.size(0),784)
            
    pre=torch.Tensor()
    pre=pre.to(device)
    for num in range(10):
        model=autoencoder()
        model.load_state_dict(torch.load('model/model{}.pth'.format(num)))
        #model.eval()
        model=model.to(device)

        svm=SVM()
        svm.load_state_dict(torch.load('model/svm{}.pth'.format(num)))
        #svm.eval()
        svm=svm.to(device)
        x,decode=model(inputs)
        y=svm(x)
        #if num==2 and bach_idx==22:
            #print('i1',inputs)
            #print('wei',model.linear3.weight.data)
            #print('o1',y)
        #print('y',y)
        pre=torch.cat([pre,y],1)
        #print('pre',pre)
    _,predict=torch.max(pre,dim=1)
    print(predict.size())
    #print('p',pre)
    #print('t',predict+1)
    #print('e',targets)
    cor+=((predict)==targets).sum().item()
    tol+=len(predict)
print('test准确率：',cor*100/tol)

