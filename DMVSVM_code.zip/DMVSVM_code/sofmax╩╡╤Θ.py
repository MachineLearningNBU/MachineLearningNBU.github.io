import torch
from torch.utils.data import Dataset,DataLoader
import numpy as np

class DiabetesDataset(Dataset):
    def __init__(self,filepath):
        xy=np.loadtxt(filepath,delimiter=',',dtype=np.float32)
        self.x_data=torch.from_numpy(xy[:,:-1])
        self.y_data=torch.from_numpy(xy[:,[-1]])
        self.len=xy.shape[0]
    def __getitem__(self, index):
        return self.x_data[index],self.y_data[index]
    def __len__(self):
        return self.len
    
dataset1=DiabetesDataset('data/6.csv')
dataset2=DiabetesDataset('data/6-2.csv')
train_loder=DataLoader(dataset=dataset1,batch_size=(64),shuffle=True)
test_loder=DataLoader(dataset=dataset2,batch_size=(64),shuffle=False)

device = torch.device("cuda")
class Model(torch.nn.Module):
    def __init__(self):
        super(Model,self).__init__()
        #self.linear1=torch.nn.Linear(254, 512)
        #self.linear2=torch.nn.Linear(512, 256)
        self.linear3=torch.nn.Linear(928, 128)
        self.linear4=torch.nn.Linear(128, 64)
        self.linear5=torch.nn.Linear(64,8)
        
        self.norm1=torch.nn.BatchNorm1d(928)
        self.norm2=torch.nn.BatchNorm1d(128)
        self.norm3=torch.nn.BatchNorm1d(64)
        self.relu=torch.nn.ReLU()
        
    def forward(self,x):
        x=self.norm1(x)
        #x=self.relu(self.linear1(x))
        #x=self.relu(self.linear2(x))
        x=self.relu(self.norm2(self.linear3(x)))
        x=self.relu(self.norm3(self.linear4(x)))

        x=self.linear5(x)
        return x

model=Model()
model.to(device)

criterion=torch.nn.CrossEntropyLoss()
optimizer=torch.optim.SGD(model.parameters(),lr=0.01)


total=0
correct=0
for epoch in range(100):
        for batch_idx,(inputs,target) in enumerate(train_loder):
            inputs=inputs.to(device)
            target = target.to(device)
            target=target.squeeze(1)
            y_pred=model(inputs)
            y_pred = y_pred.to(device)
            _,predict=torch.max(y_pred.data,dim=1)
            total+=target.size(0)
            correct+=(predict==target).sum().item()  
            loss=criterion(y_pred,target.long())
        
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        print("epoch and loss:",epoch,loss)
        print("正确率：",correct/total)
        total=0
        correct=0
      
sum1=0
total=0
correct=0
for batch_idx,(inputs,target) in enumerate(test_loder):
    inputs=inputs.to(device)
    target = target.to(device)
    target=target.squeeze(1)
    y_pred=model(inputs)
    y_pred = y_pred.to(device)
    loss=criterion(y_pred,target.long())
    _,predict=torch.max(y_pred.data,dim=1)
    total+=target.size(0)
    print(predict)
    correct+=(predict==target).sum().item()    
    sum1=sum1+loss.item()

#sum1=sum1/batch_idx    
print("loss:",sum1)
print("正确率：",correct*100/total)







