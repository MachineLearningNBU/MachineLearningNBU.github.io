import torch
from torch.utils.data import Dataset,DataLoader
import numpy as np

device = torch.device("cuda:0"if torch.cuda.is_available() else "cpu")

class DiabetesDataset(Dataset):
    def __init__(self,filepath):
        xy=np.loadtxt(filepath,delimiter=',',dtype=np.float32)
        self.x_data=torch.from_numpy(xy[:,:-1])
        self.y_data=torch.from_numpy(xy[:,[-1]])
        self.len=xy.shape[0]
    def __getitem__(self, index):
        return self.x_data[index],self.y_data[index]
    def __len__(self):
        return self.len


class autoencoder(torch.nn.Module):
    def __init__(self):
        super(autoencoder,self).__init__()
        #encoder
        self.linear1=torch.nn.Linear(928,512)
        self.linear2=torch.nn.Linear(512,256)
        self.linear3=torch.nn.Linear(256,128) 
        #decoder
        self.dlinear1=torch.nn.Linear(128,256)
        self.dlinear2=torch.nn.Linear(256,928)
        
        self.norm1=torch.nn.BatchNorm1d(928)
        self.norm2=torch.nn.BatchNorm1d(512)
        self.norm3=torch.nn.BatchNorm1d(256)
        self.norm4=torch.nn.BatchNorm1d(128)

        self.relu=torch.nn.ReLU()    
    def forward(self,x):
        #encoder
        x=self.norm1(x)
        x=self.relu(self.norm2(self.linear1(x)))
        #x=self.relu(self.norm3(self.linear2(x)))
        x=self.relu(self.norm3(self.linear2(x)))
        x=self.norm4(self.linear3(x))


        
        return x

model=autoencoder()
model.to(device)

class SVM(torch.nn.Module):
    def __init__(self):
        super(SVM,self).__init__()
        self.linear1=torch.nn.Linear(128,1)
        self.relu=torch.nn.ReLU()
        
    def forward(self,x):
        
        #x=x.view(x.size(0),512)
        x=self.linear1(x)
        return x
    
svm=SVM()
svm=svm.to(device)

optimizer1=torch.optim.Adam(svm.parameters(),lr=0.01)
optimizer2=torch.optim.Adam(model.parameters(),lr=0.01)


  
def criterion1(weight,y_pred,y_true):
    loss=pow(torch.norm(weight),2)/2+0.1*pow(torch.norm((1-y_true*y_pred)),2)
    return loss

def criterion2(inputs,code):
    loss=pow(torch.norm(inputs-code),2)
    return loss

def pred(y_pred):
    y_pred[y_pred>=0]=1
    y_pred[y_pred<0]=-1
    return y_pred

def change(targets,num):  #不等于一定在第一个，等于放在第二个
    targets[targets!=num]=-1
    targets[targets==num]=1
 
dataset1=DiabetesDataset('data/6.csv')
dataset2=DiabetesDataset('data/6-2.csv')
train_loder=DataLoader(dataset=dataset1,batch_size=(64),shuffle=True)
test_loder=DataLoader(dataset=dataset2,batch_size=(64),shuffle=False)


for num in range(1,8):
    for epoch in range(50):
        cor=0
        tol=0
        k=0 #总共24组 最后一组2个样本
        for bach_idx,(inputs,targets) in enumerate(train_loder):
            inputs=inputs.to(device)
            #print(inputs.size())
            targets=targets.to(device)
            targets=targets.squeeze(1)
            change(targets,num)
            y1=model(inputs)        
            y_pred=svm(y1)
            y_pred=y_pred.squeeze(1)
            loss=torch.mean(criterion1(svm.linear1.weight.data,y_pred,targets))
            #print(0.0001*criterion2(inputs, decode))
            optimizer1.zero_grad()
            optimizer2.zero_grad()
            loss.backward()
            optimizer1.step()
            optimizer2.step()
            #print(model.linear3.weight.grad.data)
            cor+=(pred(y_pred)==targets).sum().item()
            tol+=len(targets)
            #if(epoch==14):           
        print('num:',num)
        print('epoch:',epoch)
        acc=cor*100/tol
                #print('cor:{},tol:{}'.format(cor, tol))
        print('准确率：',acc)
        #print(bach_idx)
        
        #print('g',num,epoch,model.linear2.weight.grad.data)
    torch.save(model.state_dict(),'model/model{}.pth'.format(num))
    torch.save(svm.state_dict(),'model/svm{}.pth'.format(num))
    #if num==2:
        #print('i',inputs)
        #n,m=model(inputs)
        #print('wei',model.linear3.weight.data)
        #v=svm(n)
        #print('o',v)
        #print('1',svm.linear1.weight.data)
        #print('2',model.linear2.weight.data)
        #print('3',model.linear3.weight.data)
   
cor=0
tol=0

for bach_idx,(inputs,targets) in enumerate(test_loder):
    inputs=inputs.to(device)
    targets=targets.to(device)
    targets=targets.squeeze(1)
            
    pre=torch.Tensor()
    pre=pre.to(device)
    for num in range(1,8):
        model=autoencoder()
        model.load_state_dict(torch.load('model/model{}.pth'.format(num)))
        #model.eval()
        model=model.to(device)

        svm=SVM()
        svm.load_state_dict(torch.load('model/svm{}.pth'.format(num)))
        #svm.eval()
        svm=svm.to(device)
        x=model(inputs)
        y=svm(x)
        #if num==2 and bach_idx==22:
            #print('i1',inputs)
            #print('wei',model.linear3.weight.data)
            #print('o1',y)
        #print('y',y)
        pre=torch.cat([pre,y],1)
        #print('pre',pre)
    _,predict=torch.max(pre,dim=1)
    print(predict.size())
    #print('p',pre)
    #print('t',predict+1)
    #print('e',targets)
    cor+=((predict+1)==targets).sum().item()
    tol+=len(predict)
print('test准确率：',cor*100/tol)

