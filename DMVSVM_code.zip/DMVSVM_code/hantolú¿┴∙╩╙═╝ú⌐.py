import torch
import torch.nn as nn
import numpy as np
from torch.utils.data import Dataset,DataLoader
import random
import os

device=torch.device("cuda:0"if torch.cuda.is_available() else "cpu")

class DiabetesDataset(Dataset):
    def __init__(self,filepath):
        xy=np.loadtxt(filepath,delimiter=',',dtype=np.float32)
        self.x_data=torch.from_numpy(xy[:,:-1])
        self.y_data=torch.from_numpy(xy[:,[-1]])
        self.len=xy.shape[0]
    def __getitem__(self, index):
        return self.x_data[index],self.y_data[index]
    def __len__(self):
        return self.len

class autoencoder1(torch.nn.Module):
    def __init__(self):
        super(autoencoder1,self).__init__()
        #encoder
        self.linear1=nn.Linear(76,64)
        self.linear2=nn.Linear(64,32)
        #decoder
        self.dlinear1=nn.Linear(32,64)
        self.dlinear2=nn.Linear(64,76)
        
        self.norm1=torch.nn.BatchNorm1d(76)
        self.norm2=torch.nn.BatchNorm1d(64)
        self.norm3=torch.nn.BatchNorm1d(32)

        self.relu=torch.nn.ReLU()    
    def forward(self,x):
        #encoder
        x=self.norm1(x)
        x=self.relu(self.norm2(self.linear1(x)))
        x=self.norm3(self.linear2(x))
        #decoder
        code=self.relu(self.norm2(self.dlinear1(x)))
        code=self.dlinear2(code)
        return x,code
model1=autoencoder1().to(device)

class SVM11(torch.nn.Module):
    def __init__(self):
        super(SVM11,self).__init__()
        self.linear1=torch.nn.Linear(32,1)
        
    def forward(self,x):
        x=self.linear1(x)
        return x
svm11=SVM11().to(device)

class SVM12(torch.nn.Module):
    def __init__(self):
        super(SVM12,self).__init__()
        self.linear1=torch.nn.Linear(32,1)
        
    def forward(self,x):
        x=self.linear1(x)
        return x
svm12=SVM12().to(device)
    
class autoencoder2(torch.nn.Module):
    def __init__(self):
        super(autoencoder2,self).__init__()
        #encoder
        self.linear1=torch.nn.Linear(64,60)
        self.linear2=torch.nn.Linear(60,32)
        self.dlinear1=torch.nn.Linear(32,60)
        self.dlinear2=torch.nn.Linear(60,64)
        
        self.norm1=torch.nn.BatchNorm1d(64)
        self.norm2=torch.nn.BatchNorm1d(60)
        self.norm3=torch.nn.BatchNorm1d(32)
        #self.norm4=torch.nn.BatchNorm1d(128)

        self.relu=torch.nn.ReLU()    
    def forward(self,x):
        #encoder
        x=self.norm1(x)
        x=self.relu(self.norm2(self.linear1(x)))
        x=self.norm3(self.linear2(x))
        code=self.norm2(self.dlinear1(x))
        code=self.dlinear2(code)
        return x,code
model2=autoencoder2().to(device)

class SVM21(torch.nn.Module):
    def __init__(self):
        super(SVM21,self).__init__()
        self.linear1=torch.nn.Linear(32,1)
        
    def forward(self,x):
        x=self.linear1(x)
        return x
svm21=SVM21().to(device)

class SVM22(torch.nn.Module):
    def __init__(self):
        super(SVM22,self).__init__()
        self.linear1=torch.nn.Linear(32,1)
        
    def forward(self,x):
        x=self.linear1(x)
        return x
svm22=SVM22().to(device)

class autoencoder3(torch.nn.Module):
    def __init__(self):
        super(autoencoder3,self).__init__()
        #encoder
        self.linear1=torch.nn.Linear(216,200)
        self.linear2=torch.nn.Linear(200,128)
        self.dlinear1=torch.nn.Linear(128,200)
        self.dlinear2=torch.nn.Linear(200, 216)
        
        self.norm1=torch.nn.BatchNorm1d(216)
        self.norm2=torch.nn.BatchNorm1d(200)
        self.norm3=torch.nn.BatchNorm1d(128)

        self.relu=torch.nn.ReLU()    
    def forward(self,x):
        #encoder
        x=self.norm1(x)
        x=self.relu(self.norm2(self.linear1(x)))
        x=self.norm3(self.linear2(x))
        code=self.relu(self.norm2(self.dlinear1(x)))
        code=self.dlinear2(code)
        return x,code
model3=autoencoder3().to(device)

class SVM31(torch.nn.Module):
    def __init__(self):
        super(SVM31,self).__init__()
        self.linear1=torch.nn.Linear(128,1)
        
    def forward(self,x):
        x=self.linear1(x)
        return x
svm31=SVM31().to(device)

class SVM32(torch.nn.Module):
    def __init__(self):
        super(SVM32,self).__init__()
        self.linear1=torch.nn.Linear(128,1)
        
    def forward(self,x):
        x=self.linear1(x)
        return x
svm32=SVM32().to(device)

class autoencoder4(torch.nn.Module):
    def __init__(self):
        super(autoencoder4,self).__init__()
        #encoder
        self.linear1=torch.nn.Linear(240,200)
        self.linear2=torch.nn.Linear(200,128)
        self.linear3=torch.nn.Linear(128,64) 
        self.dlinear1=torch.nn.Linear(64, 128)
        self.dlinear2=torch.nn.Linear(128, 200)
        self.dlinear3=torch.nn.Linear(200, 240)
        
        self.norm1=torch.nn.BatchNorm1d(240)
        self.norm2=torch.nn.BatchNorm1d(200)
        self.norm3=torch.nn.BatchNorm1d(128)
        self.norm4=torch.nn.BatchNorm1d(64)

        self.relu=torch.nn.ReLU()    
    def forward(self,x):
        #encoder
        x=self.norm1(x)
        x=self.relu(self.norm2(self.linear1(x)))
        x=self.relu(self.norm3(self.linear2(x)))
        x=self.norm4(self.linear3(x))
        #decoder
        code=self.relu(self.norm3(self.dlinear1(x)))
        code=self.relu(self.norm2(self.dlinear2(code)))
        code=self.dlinear3(code)
        
        return x,code
model4=autoencoder4().to(device)

class SVM41(torch.nn.Module):
    def __init__(self):
        super(SVM41,self).__init__()
        self.linear1=torch.nn.Linear(64,1)
        
    def forward(self,x):
        x=self.linear1(x)
        return x
svm41=SVM41().to(device)

class SVM42(torch.nn.Module):
    def __init__(self):
        super(SVM42,self).__init__()
        self.linear1=torch.nn.Linear(64,1)
        
    def forward(self,x):
        x=self.linear1(x)
        return x
svm42=SVM42().to(device)

class autoencoder5(torch.nn.Module):
    def __init__(self):
        super(autoencoder5,self).__init__()
        #encoder
        self.linear1=torch.nn.Linear(47,40)
        self.linear2=torch.nn.Linear(40,32)
        self.dlinear1=torch.nn.Linear(32, 40)
        self.dlinear2=torch.nn.Linear(40,47)
        
        self.norm1=torch.nn.BatchNorm1d(47)
        self.norm2=torch.nn.BatchNorm1d(40)
        self.norm3=torch.nn.BatchNorm1d(32)
        #self.norm4=torch.nn.BatchNorm1d(32)

        self.relu=torch.nn.ReLU()    
    def forward(self,x):
        #encoder
        x=self.norm1(x)
        x=self.relu(self.norm2(self.linear1(x)))
        x=self.norm3(self.linear2(x))
        #decoder
        code=self.relu(self.norm2(self.dlinear1(x)))
        code=self.dlinear2(code)
        
        return x,code
model5=autoencoder5().to(device)

class SVM51(torch.nn.Module):
    def __init__(self):
        super(SVM51,self).__init__()
        self.linear1=torch.nn.Linear(32,1)
        
    def forward(self,x):
        x=self.linear1(x)
        return x
svm51=SVM51().to(device)

class SVM52(torch.nn.Module):
    def __init__(self):
        super(SVM52,self).__init__()
        self.linear1=torch.nn.Linear(32,1)
        
    def forward(self,x):
        x=self.linear1(x)
        return x
svm52=SVM52().to(device)

class autoencoder6(torch.nn.Module):
    def __init__(self):
        super(autoencoder6,self).__init__()
        #encoder
        self.linear1=torch.nn.Linear(6,32)
        self.linear2=torch.nn.Linear(32,64)
        self.dlinear1=torch.nn.Linear(64, 32)
        self.dlinear2=torch.nn.Linear(32,6)
        
        self.norm1=torch.nn.BatchNorm1d(6)
        self.norm2=torch.nn.BatchNorm1d(32)
        self.norm3=torch.nn.BatchNorm1d(64)

        self.relu=torch.nn.ReLU()    
    def forward(self,x):
        #encoder
        x=self.norm1(x)
        x=self.relu(self.norm2(self.linear1(x)))
        x=self.norm3(self.linear2(x))
        
        code=self.relu(self.norm2(self.dlinear1(x)))
        code=self.dlinear2(code)
        return x,code
model6=autoencoder6().to(device)

class SVM61(torch.nn.Module):
    def __init__(self):
        super(SVM61,self).__init__()
        self.linear1=torch.nn.Linear(64,1)
        
    def forward(self,x):
        x=self.linear1(x)
        return x
svm61=SVM61().to(device)

class SVM62(torch.nn.Module):
    def __init__(self):
        super(SVM62,self).__init__()
        self.linear1=torch.nn.Linear(64,1)
        
    def forward(self,x):
        x=self.linear1(x)
        return x
svm62=SVM62().to(device)

def shuffle(inputs,targets,seed):
    inp=torch.Tensor().to(device)
    tar=torch.Tensor().to(device)
    inp=inputs[seed.long()].to(device)
    tar=targets[seed.long()].squeeze().to(device)
    return inp,tar
  
def separate(starsite,endsite):
    for bach,(i,t) in enumerate(train_loder2):
        setup_seed(20)
        seed=torch.randperm(i.size(0))
    for bach,(i,t) in enumerate(train_loder1):
        i=i.to(device)
        t=t.to(device)
        inputs,targets=shuffle(i,t,seed)
        train1=inputs[0:starsite,:]
        test1=inputs[starsite:endsite,:]
        train1=torch.cat([train1,inputs[endsite:batch_size,:]],dim=0)
    for bach,(i,t) in enumerate(train_loder2):
        i=i.to(device)
        t=t.to(device)
        inputs,targets=shuffle(i,t,seed)
        train2=inputs[0:starsite,:]
        test2=inputs[starsite:endsite,:]
        train_t=targets[0:starsite]
        test_t=targets[starsite:endsite]
        train2=torch.cat([train2,inputs[endsite:batch_size,:]],dim=0)
        train_t=torch.cat([train_t,targets[endsite:batch_size]],dim=0)
    for bach,(i,t) in enumerate(train_loder3):
        i=i.to(device)
        t=t.to(device)
        inputs,targets=shuffle(i,t,seed)
        train3=inputs[0:starsite,:]
        test3=inputs[starsite:endsite,:]
        train3=torch.cat([train3,inputs[endsite:batch_size,:]],dim=0)
    for bach,(i,t) in enumerate(train_loder4):
        i=i.to(device)
        t=t.to(device)
        inputs,targets=shuffle(i,t,seed)
        train4=inputs[0:starsite,:]
        test4=inputs[starsite:endsite,:]
        train4=torch.cat([train4,inputs[endsite:batch_size,:]],dim=0)
    for bach,(i,t) in enumerate(train_loder5):
        i=i.to(device)
        t=t.to(device)
        inputs,targets=shuffle(i,t,seed)
        train5=inputs[0:starsite,:]
        test5=inputs[starsite:endsite,:]
        train5=torch.cat([train5,inputs[endsite:batch_size,:]],dim=0)
    for bach,(i,t) in enumerate(train_loder6):
        i=i.to(device)
        t=t.to(device)
        inputs,targets=shuffle(i,t,seed)
        train6=inputs[0:starsite,:]
        test6=inputs[starsite:endsite,:]
        train6=torch.cat([train6,inputs[endsite:batch_size,:]],dim=0)
    return train1,test1,train2,test2,train3,test3,train4,test4,train5,test5,train6,test6,train_t,test_t

def lossfunction(w1,w2,y11,y12,y21,y22,x,code):
    loss=(pow(torch.norm(w1),2)+pow(torch.norm(w2),2))/2+mu1*(pow(torch.norm(y11),2)+pow(torch.norm(y22),2))+mu2*(pow(torch.norm(y11-y12-1),2)+
    pow(torch.norm(y22-y21-1),2))+1*torch.norm(x-code)
    return loss

def change(targets,num):  #不等于一定在第一个，等于放在第二个
    targets[targets!=num]=-1
    targets[targets==num]=1
    
def split(inputs,targets):
    inputs1=torch.Tensor().to(device)
    inputs2=torch.Tensor().to(device)
    inputs1=inputs[torch.where(targets==1)].to(device)
    inputs2=inputs[torch.where(targets==-1)].to(device)
    return inputs1,inputs2

# def check(y1,y2):
#     y1[torch.where(abs(y1)<abs(y2))]=1
#     y1[torch.where(abs(y1)>abs(y2)) and abs(y1)!=1]=-1
#     return y1

def combineloss(pre):
    loss=0
    for i in range(pre.size(1)):
        for j in range(i+1,pre.size(1)):
            loss+=torch.norm(pre[:,i]-pre[:,j])
    return loss

def vote(pre):
    a=torch.zeros(pre.size(0),20).to(device)
    for i in range(pre.size(0)):
        for j in range(pre.size(1)):
            a[i][int(pre[i][j])]+=1
    _,predict=torch.max(a,dim=1)
    return predict

def setup_seed(seed):
      torch.manual_seed(seed)
      torch.cuda.manual_seed_all(seed)
      np.random.seed(seed)
      random.seed(seed)
      torch.backends.cudnn.deterministic = True

def weights_init(m):
    classname = m.__class__.__name__
    if classname.find('Linear') != -1:
        m.weight.data.normal_(0.0, pow(2/(m.weight.data.size(0)+m.weight.data.size(1)),1/2))                                             
        m.bias.data.fill_(0) 
        
lr=0.005
mu1=1
mu2=1
mu3=1
epoch_num=50#epoch次数
round_num=1
k=0#选出数组k个位置的数值作为随机种子
batch_size=2000#样本总大小
scale=int(batch_size/5)#每组样本的大小
file='model3'#模型存储文件夹名字
randarray=torch.randperm(100000)#用于每个epoch生层不同随机种子

if not os.path.exists('./{}'.format(file)):
    os.mkdir('./{}'.format(file))

dataset1=DiabetesDataset('data2/1.csv')
train_loder1=DataLoader(dataset=dataset1,batch_size=batch_size,shuffle=False)
dataset2=DiabetesDataset('data2/2.csv')
train_loder2=DataLoader(dataset=dataset2,batch_size=batch_size,shuffle=False)
dataset3=DiabetesDataset('data2/3.csv')
train_loder3=DataLoader(dataset=dataset3,batch_size=batch_size,shuffle=False)
dataset4=DiabetesDataset('data2/4.csv')
train_loder4=DataLoader(dataset=dataset4,batch_size=batch_size,shuffle=False)
dataset5=DiabetesDataset('data2/5.csv')
train_loder5=DataLoader(dataset=dataset5,batch_size=batch_size,shuffle=False)
dataset6=DiabetesDataset('data2/6.csv')
train_loder6=DataLoader(dataset=dataset6,batch_size=batch_size,shuffle=False)

opt_model1=torch.optim.Adam(model1.parameters(),lr=lr)
opt_svm11=torch.optim.Adam(svm11.parameters(),lr=lr)
opt_svm12=torch.optim.Adam(svm12.parameters(),lr=lr)
opt_model2=torch.optim.Adam(model2.parameters(),lr=lr)
opt_svm21=torch.optim.Adam(svm21.parameters(),lr=lr)
opt_svm22=torch.optim.Adam(svm22.parameters(),lr=lr)
opt_model3=torch.optim.Adam(model3.parameters(),lr=lr)
opt_svm31=torch.optim.Adam(svm31.parameters(),lr=lr)
opt_svm32=torch.optim.Adam(svm32.parameters(),lr=lr)
opt_model4=torch.optim.Adam(model4.parameters(),lr=lr)
opt_svm41=torch.optim.Adam(svm41.parameters(),lr=lr)
opt_svm42=torch.optim.Adam(svm42.parameters(),lr=lr)
opt_model5=torch.optim.Adam(model5.parameters(),lr=lr)
opt_svm51=torch.optim.Adam(svm51.parameters(),lr=lr)
opt_svm52=torch.optim.Adam(svm52.parameters(),lr=lr)
opt_model6=torch.optim.Adam(model6.parameters(),lr=lr)
opt_svm61=torch.optim.Adam(svm61.parameters(),lr=lr)
opt_svm62=torch.optim.Adam(svm62.parameters(),lr=lr)

tolacc=[]
for round in range(round_num):
    for times in range(1,6):
        starsite=(times-1)*scale#交叉验证起始位置
        endsite=starsite+scale#交叉验证结束位置
        train1,test1,train2,test2,train3,test3,train4,test4,train5,test5,train6,test6,train_t,test_t=separate(starsite,endsite)
        model1.apply(weights_init)
        model2.apply(weights_init)
        model3.apply(weights_init)
        model4.apply(weights_init)
        model5.apply(weights_init)
        model6.apply(weights_init)
        svm11.apply(weights_init)
        svm12.apply(weights_init)
        svm21.apply(weights_init)
        svm22.apply(weights_init)
        svm31.apply(weights_init)
        svm32.apply(weights_init)
        svm41.apply(weights_init)
        svm42.apply(weights_init)
        svm51.apply(weights_init)
        svm52.apply(weights_init)
        svm61.apply(weights_init)
        svm62.apply(weights_init)
        for num in range(1,11):
            for epoch in range(epoch_num):
                cor1=0
                tol1=0
                setup_seed(randarray[k])
                k+=1
                seed=torch.randperm(len(train_t))
                i1,t1=shuffle(train1, train_t.unsqueeze(1),seed)
                i2,t2=shuffle(train2, train_t.unsqueeze(1),seed)
                i3,t3=shuffle(train3, train_t.unsqueeze(1),seed)
                i4,t4=shuffle(train4, train_t.unsqueeze(1),seed)
                i5,t5=shuffle(train5, train_t.unsqueeze(1),seed)
                i6,t6=shuffle(train6, train_t.unsqueeze(1),seed)
                for idx in range(4):
                    pre1=torch.Tensor().to(device)
                    pre2=torch.Tensor().to(device)
                    loss=0
                    for view in range(1,7):
                        if view==1:
                            inputs=i1[idx*scale:(idx+1)*scale,:].to(device)
                            targets=t1[idx*scale:(idx+1)*scale].to(device)
                            change(targets,num)
                            x1,code=model1(inputs)
                            inputs1,inputs2=split(x1, targets)
                            y_s1_pred11=svm11(inputs1).reshape(-1)
                            y_s1_pred12=svm12(inputs1).reshape(-1)
                            y_s1_pred21=svm11(inputs2).reshape(-1)
                            y_s1_pred22=svm12(inputs2).reshape(-1)
                            y1=svm11(inputs1).reshape(-1)
                            y2=svm12(inputs2).reshape(-1)
                            pre1=torch.cat([pre1,y1.unsqueeze(1)],dim=1)
                            pre2=torch.cat([pre2,y2.unsqueeze(1)],dim=1)
                            loss+=lossfunction(svm11.linear1.weight.data,svm12.linear1.weight.data,y_s1_pred11,y_s1_pred12,y_s1_pred21,y_s1_pred22,inputs,code)
                        if view==2:
                            inputs=i2[idx*scale:(idx+1)*scale,:].to(device)
                            targets=t2[idx*scale:(idx+1)*scale].to(device)
                            change(targets,num)
                            x1,code=model2(inputs)
                            inputs1,inputs2=split(x1, targets)
                            y_s2_pred11=svm21(inputs1).reshape(-1)
                            y_s2_pred12=svm22(inputs1).reshape(-1)
                            y_s2_pred21=svm21(inputs2).reshape(-1)
                            y_s2_pred22=svm22(inputs2).reshape(-1)
                            y1=svm21(inputs1).reshape(-1)
                            y2=svm22(inputs2).reshape(-1)
                            pre1=torch.cat([pre1,y1.unsqueeze(1)],dim=1)
                            pre2=torch.cat([pre2,y2.unsqueeze(1)],dim=1)
                            # y1=check(y1, y2)
                            # cor2+=(y1==targets).sum().item()
                            # tol2+=len(targets)
                            loss+=lossfunction(svm21.linear1.weight.data,svm22.linear1.weight.data,y_s2_pred11,y_s2_pred12,y_s2_pred21,y_s2_pred22,inputs,code)
                        if view==3:
                            inputs=i3[idx*scale:(idx+1)*scale,:].to(device)
                            targets=t3[idx*scale:(idx+1)*scale].to(device)
                            change(targets,num)
                            x1,code=model3(inputs)
                            inputs1,inputs2=split(x1, targets)
                            y_s3_pred11=svm31(inputs1).reshape(-1)
                            y_s3_pred12=svm32(inputs1).reshape(-1)
                            y_s3_pred21=svm31(inputs2).reshape(-1)
                            y_s3_pred22=svm32(inputs2).reshape(-1)
                            y1=svm31(inputs1).reshape(-1)
                            y2=svm32(inputs2).reshape(-1)
                            pre1=torch.cat([pre1,y1.unsqueeze(1)],dim=1)
                            pre2=torch.cat([pre2,y2.unsqueeze(1)],dim=1)
                            # y1=check(y1, y2)
                            # cor3+=(y1==targets).sum().item()
                            # tol3+=len(targets)
                            loss+=lossfunction(svm31.linear1.weight.data,svm32.linear1.weight.data,y_s3_pred11,y_s3_pred12,y_s3_pred21,y_s3_pred22,inputs,code)
                        if view==4:
                            inputs=i4[idx*scale:(idx+1)*scale,:].to(device)
                            targets=t4[idx*scale:(idx+1)*scale].to(device)
                            change(targets,num)
                            x1,code=model4(inputs)
                            inputs1,inputs2=split(x1, targets)
                            y_s4_pred11=svm41(inputs1).reshape(-1)
                            y_s4_pred12=svm42(inputs1).reshape(-1)
                            y_s4_pred21=svm41(inputs2).reshape(-1)
                            y_s4_pred22=svm42(inputs2).reshape(-1)
                            y1=svm41(inputs1).reshape(-1)
                            y2=svm42(inputs2).reshape(-1)
                            pre1=torch.cat([pre1,y1.unsqueeze(1)],dim=1)
                            pre2=torch.cat([pre2,y2.unsqueeze(1)],dim=1)
                            # y1=check(y1, y2)
                            # cor4+=(y1==targets).sum().item()
                            # tol4+=len(targets)
                            loss+=lossfunction(svm41.linear1.weight.data,svm42.linear1.weight.data,y_s4_pred11,y_s4_pred12,y_s4_pred21,y_s4_pred22,inputs,code)
                        if view==5:
                            inputs=i5[idx*scale:(idx+1)*scale,:].to(device)
                            targets=t5[idx*scale:(idx+1)*scale].to(device)
                            change(targets,num)
                            x1,code=model5(inputs)
                            inputs1,inputs2=split(x1, targets)
                            y_s5_pred11=svm51(inputs1).reshape(-1)
                            y_s5_pred12=svm52(inputs1).reshape(-1)
                            y_s5_pred21=svm51(inputs2).reshape(-1)
                            y_s5_pred22=svm52(inputs2).reshape(-1)
                            y1=svm51(inputs1).reshape(-1)
                            y2=svm52(inputs2).reshape(-1)
                            pre1=torch.cat([pre1,y1.unsqueeze(1)],dim=1)
                            pre2=torch.cat([pre2,y2.unsqueeze(1)],dim=1)
                            # y1=check(y1, y2)
                            # cor4+=(y1==targets).sum().item()
                            # tol4+=len(targets)
                            loss+=lossfunction(svm51.linear1.weight.data,svm52.linear1.weight.data,y_s5_pred11,y_s5_pred12,y_s5_pred21,y_s5_pred22,inputs,code)
                        if view==6:
                            inputs=i6[idx*scale:(idx+1)*scale,:].to(device)
                            targets=t6[idx*scale:(idx+1)*scale].to(device)
                            change(targets,num)
                            x1,code=model6(inputs)
                            inputs1,inputs2=split(x1, targets)
                            y_s6_pred11=svm61(inputs1).reshape(-1)
                            y_s6_pred12=svm62(inputs1).reshape(-1)
                            y_s6_pred21=svm61(inputs2).reshape(-1)
                            y_s6_pred22=svm62(inputs2).reshape(-1)
                            y1=svm61(inputs1).reshape(-1)
                            y2=svm62(inputs2).reshape(-1)
                            pre1=torch.cat([pre1,y1.unsqueeze(1)],dim=1)
                            pre2=torch.cat([pre2,y2.unsqueeze(1)],dim=1)
                            # y1=check(y1, y2)
                            # cor4+=(y1==targets).sum().item()
                            # tol4+=len(targets)
                            loss+=lossfunction(svm61.linear1.weight.data,svm62.linear1.weight.data,y_s6_pred11,y_s6_pred12,y_s6_pred21,y_s6_pred22,inputs,code)
                    loss+=mu3*(combineloss(pre1)+combineloss(pre2))
                    opt_model1.zero_grad()
                    opt_model2.zero_grad()
                    opt_model3.zero_grad()
                    opt_model4.zero_grad()
                    opt_model5.zero_grad()
                    opt_model6.zero_grad()
                    opt_svm11.zero_grad()
                    opt_svm12.zero_grad()
                    opt_svm21.zero_grad()
                    opt_svm22.zero_grad()
                    opt_svm31.zero_grad()
                    opt_svm32.zero_grad()
                    opt_svm41.zero_grad()
                    opt_svm42.zero_grad()
                    opt_svm51.zero_grad()
                    opt_svm52.zero_grad()
                    opt_svm61.zero_grad()
                    opt_svm62.zero_grad()
                    loss.backward()
                    opt_model1.step()
                    opt_model2.step()
                    opt_model3.step()
                    opt_model4.step()
                    opt_model5.step()
                    opt_model6.step()
                    opt_svm11.step()
                    opt_svm12.step()
                    opt_svm21.step()
                    opt_svm22.step()
                    opt_svm31.step()
                    opt_svm32.step()
                    opt_svm41.step()
                    opt_svm42.step()
                    opt_svm51.step()
                    opt_svm52.step()
                    opt_svm61.step()
                    opt_svm62.step()
                # acc2=cor2*100/tol2
                # acc3=cor3*100/tol3
                # acc4=cor4*100/tol4
                print(f"round:{round}/{round_num} time:{times} num:{num} eopch:{epoch}/{epoch_num}: loss:{loss}")
                # print("acc2:{}\nacc3:{}\nacc4:{}\n".format(acc2, acc3, acc4))
            torch.save(model1.state_dict(),'{}/model1{}.pth'.format(file,num))
            torch.save(svm11.state_dict(),'{}/svm11{}.pth'.format(file,num))
            torch.save(svm12.state_dict(),'{}/svm12{}.pth'.format(file,num))
            torch.save(model2.state_dict(),'{}/model2{}.pth'.format(file,num))
            torch.save(svm21.state_dict(),'{}/svm21{}.pth'.format(file,num))
            torch.save(svm22.state_dict(),'{}/svm22{}.pth'.format(file,num))
            torch.save(model3.state_dict(),'{}/model3{}.pth'.format(file,num))
            torch.save(svm31.state_dict(),'{}/svm31{}.pth'.format(file,num))
            torch.save(svm32.state_dict(),'{}/svm32{}.pth'.format(file,num))
            torch.save(model4.state_dict(),'{}/model4{}.pth'.format(file,num))
            torch.save(svm41.state_dict(),'{}/svm41{}.pth'.format(file,num))
            torch.save(svm42.state_dict(),'{}/svm42{}.pth'.format(file,num))
            torch.save(model5.state_dict(),'{}/model5{}.pth'.format(file,num))
            torch.save(svm51.state_dict(),'{}/svm51{}.pth'.format(file,num))
            torch.save(svm52.state_dict(),'{}/svm52{}.pth'.format(file,num))
            torch.save(model6.state_dict(),'{}/model6{}.pth'.format(file,num))
            torch.save(svm61.state_dict(),'{}/svm61{}.pth'.format(file,num))
            torch.save(svm62.state_dict(),'{}/svm62{}.pth'.format(file,num))
            
        cor=0
        tol=0
        cor1=0
        tol1=0
        cor2=0
        tol2=0
        cor3=0
        tol3=0
        cor4=0
        tol4=0
        cor5=0
        tol5=0
        cor6=0
        tol6=0
        pre=torch.Tensor().to(device)
        for idx in range(1):
            for view in range(1,7):
                temppre=torch.Tensor().to(device)
                if view==4:
                    inputs=test1[idx*scale:(idx+1)*scale,:].to(device)
                    targets=test_t[idx*scale:(idx+1)*scale].to(device)
                    for num in range(1,11):
                        model=autoencoder1()
                        model.load_state_dict(torch.load('{}/model1{}.pth'.format(file,num)))
                        model=model.to(device)
                        svm1=SVM11()
                        svm1.load_state_dict(torch.load('{}/svm11{}.pth'.format(file,num)))
                        svm1=svm1.to(device)
                        svm2=SVM12()
                        svm2.load_state_dict(torch.load('{}/svm12{}.pth'.format(file,num)))
                        svm2=svm2.to(device)
                        x,code=model(inputs)
                        y1=svm1(x)
                        temppre=torch.cat([temppre,y1],1)
                    _,predict=torch.min(abs(temppre),dim=1)
                    predict=predict+1
                    cor1+=(predict==targets).sum().item()
                    tol1+=len(predict)
                    print("acc1:",cor1*100/tol1)
                    pre=torch.cat([pre,predict.unsqueeze(1)],1)
                if view==3:
                    inputs=test2[idx*scale:(idx+1)*scale,:].to(device)
                    targets=test_t[idx*scale:(idx+1)*scale].to(device)
                    for num in range(1,11):
                        model=autoencoder2()
                        model.load_state_dict(torch.load('{}/model2{}.pth'.format(file,num)))
                        model=model.to(device)
                        svm1=SVM21()
                        svm1.load_state_dict(torch.load('{}/svm21{}.pth'.format(file,num)))
                        svm1=svm1.to(device)
                        svm2=SVM22()
                        svm2.load_state_dict(torch.load('{}/svm22{}.pth'.format(file,num)))
                        svm2=svm2.to(device)
                        x,code=model(inputs)
                        y1=svm1(x)
                        temppre=torch.cat([temppre,y1],1)
                    _,predict=torch.min(abs(temppre),dim=1)
                    predict=predict+1
                    cor2+=(predict==targets).sum().item()
                    tol2+=len(predict)
                    print("acc2:",cor2*100/tol2)
                    pre=torch.cat([pre,predict.unsqueeze(1)],1)
                if view==1:
                    inputs=test3[idx*scale:(idx+1)*scale,:].to(device)
                    targets=test_t[idx*scale:(idx+1)*scale].to(device)
                    for num in range(1,11):
                        model=autoencoder3()
                        model.load_state_dict(torch.load('{}/model3{}.pth'.format(file,num)))
                        model=model.to(device)
                        svm1=SVM31()
                        svm1.load_state_dict(torch.load('{}/svm31{}.pth'.format(file,num)))
                        svm1=svm1.to(device)
                        svm2=SVM32()
                        svm2.load_state_dict(torch.load('{}/svm32{}.pth'.format(file,num)))
                        svm2=svm2.to(device)
                        x,code=model(inputs)
                        y1=svm1(x)
                        temppre=torch.cat([temppre,y1],1)
                    _,predict=torch.min(abs(temppre),dim=1)
                    predict=predict+1
                    cor3+=(predict==targets).sum().item()
                    tol3+=len(predict)
                    print("acc3:",cor3*100/tol3)
                    pre=torch.cat([pre,predict.unsqueeze(1)],1)
                if view==2:
                    inputs=test4[idx*scale:(idx+1)*scale,:].to(device)
                    targets=test_t[idx*scale:(idx+1)*scale].to(device)
                    for num in range(1,11):
                        model=autoencoder4()
                        model.load_state_dict(torch.load('{}/model4{}.pth'.format(file,num)))
                        model=model.to(device)
                        svm1=SVM41()
                        svm1.load_state_dict(torch.load('{}/svm41{}.pth'.format(file,num)))
                        svm1=svm1.to(device)
                        svm2=SVM42()
                        svm2.load_state_dict(torch.load('{}/svm42{}.pth'.format(file,num)))
                        svm2=svm2.to(device)
                        x,code=model(inputs)
                        y1=svm1(x)
                        temppre=torch.cat([temppre,y1],1)
                    _,predict=torch.min(abs(temppre),dim=1)
                    predict=predict+1
                    cor4+=(predict==targets).sum().item()
                    tol4+=len(predict)
                    print("acc4:",cor4*100/tol4)
                    pre=torch.cat([pre,predict.unsqueeze(1)],1)
                if view==5:
                    inputs=test5[idx*scale:(idx+1)*scale,:].to(device)
                    targets=test_t[idx*scale:(idx+1)*scale].to(device)
                    for num in range(1,11):
                        model=autoencoder5()
                        model.load_state_dict(torch.load('{}/model5{}.pth'.format(file,num)))
                        model=model.to(device)
                        svm1=SVM51()
                        svm1.load_state_dict(torch.load('{}/svm51{}.pth'.format(file,num)))
                        svm1=svm1.to(device)
                        svm2=SVM52()
                        svm2.load_state_dict(torch.load('{}/svm52{}.pth'.format(file,num)))
                        svm2=svm2.to(device)
                        x,code=model(inputs)
                        y1=svm1(x)
                        temppre=torch.cat([temppre,y1],1)
                    _,predict=torch.min(abs(temppre),dim=1)
                    predict=predict+1
                    cor5+=(predict==targets).sum().item()
                    tol5+=len(predict)
                    print("acc5:",cor5*100/tol5)
                    pre=torch.cat([pre,predict.unsqueeze(1)],1)
                if view==6:
                    inputs=test6[idx*scale:(idx+1)*scale,:].to(device)
                    targets=test_t[idx*scale:(idx+1)*scale].to(device)
                    for num in range(1,11):
                        model=autoencoder6()
                        model.load_state_dict(torch.load('{}/model6{}.pth'.format(file,num)))
                        model=model.to(device)
                        svm1=SVM61()
                        svm1.load_state_dict(torch.load('{}/svm61{}.pth'.format(file,num)))
                        svm1=svm1.to(device)
                        svm2=SVM62()
                        svm2.load_state_dict(torch.load('{}/svm62{}.pth'.format(file,num)))
                        svm2=svm2.to(device)
                        x,code=model(inputs)
                        y1=svm1(x)
                        temppre=torch.cat([temppre,y1],1)
                    _,predict=torch.min(abs(temppre),dim=1)
                    predict=predict+1
                    cor6+=(predict==targets).sum().item()
                    tol6+=len(predict)
                    print("acc6:",cor6*100/tol6)
                    pre=torch.cat([pre,predict.unsqueeze(1)],1)
            predict=vote(pre)
            cor+=(predict==targets).sum().item()
            tol+=len(targets)
            acc=cor*100/tol
            #print('pre:',pre)
            #print('targets:',targets)
            #print('predict:',predict)
            #print('distance:',targets-predict)
            print('acc:',acc)
            tolacc.append(acc)

print('tolacc:',tolacc)
avgacc=0
total=0
for i in range(len(tolacc)):
    total+=tolacc[i]
avgacc=total/len(tolacc)
print('average acc:',avgacc)
    
tol=0
for i in range(len(tolacc)):
    tol+=pow(tolacc[i]-avgacc,2)
print('Standard deviation:',pow(tol/len(tolacc),0.5))  





































































